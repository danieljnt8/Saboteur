package fop.io;

import java.io.*;
import java.util.LinkedList;
import java.util.List;

import fop.model.ScoreEntry;

/**
 * 
 * Wird genutzt, um {@link ScoreEntry} Objekte zu schreiben und zu lesen.<br>
 * <br>
 * Es handelt sich um die Datei {@value #PATH}.<br>
 * Mit {@link #loadScoreEntries()} werden die Elemente gelesen.<br>
 * Mit {@link #writeScoreEntries(List)} werden die Elemente geschrieben.
 *
 */
public final class ScoreEntryIO {
	
	/** Der Pfad zur ScoreEntry Datei */
	private static String PATH = "highscores.txt";
	
	private ScoreEntryIO() {}
	
	/**
	 * Liest eine Liste von {@link ScoreEntry} Objekten aus der Datei {@value #PATH}.<br>
	 * Die Liste enthält die Elemente in der Reihenfolge, in der sie in der Datei vorkommen.<br>
	 * Ungültige Einträge werden nicht zurückgegeben.
	 * @return die ScoreEntry Objekte
	 */
	public static List<ScoreEntry> loadScoreEntries() {
		File file = new File(PATH);
		if (!file.exists()) return new LinkedList<>();
		
		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			List<ScoreEntry> scoreEntries = new LinkedList<>();
			String line;
			while ((line = br.readLine()) != null) {
				ScoreEntry scoreEntry = ScoreEntry.read(line);
				if (scoreEntry != null)
					scoreEntries.add(scoreEntry);
			}
			return scoreEntries;
		} catch (IOException e) {
			e.printStackTrace();
			return new LinkedList<>();
		}
	}
	
	/**
	 * Schreibt eine Liste von {@link ScoreEntry} Objekten in die Datei {@value #PATH}.<br>
	 * Die Elemente werden in der Reihenfolge in die Datei geschrieben, in der sie in der Liste vorkommen.
	 * @param scoreEntries die zu schreibenden ScoreEntry Objekte
	 */
	public static void writeScoreEntries(List<ScoreEntry> scoreEntries) {
		try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(PATH)))) {
			for (ScoreEntry scoreEntry : scoreEntries)
				scoreEntry.write(pw);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Schreibt das übergebene {@link ScoreEntry} Objekt an der korrekten Stelle in die Datei {@value #PATH}.<br>
	 * Die Elemente sollen absteigend sortiert sein. Wenn das übergebene Element dieselbe Punktzahl wie ein
	 * Element der Datei hat, soll das übergebene Element danach eingefügt werden.
	 * @param scoreEntry das ScoreEntry Objekt, das hinzugefügt werden soll
	 */
	public static void addScoreEntry(ScoreEntry scoreEntry) {
		List<ScoreEntry> scoreEntries = loadScoreEntries();
		
		int i;
		for (i = 0; i < scoreEntries.size(); i++)
			if (scoreEntries.get(i).compareTo(scoreEntry) < 0) break;
		scoreEntries.add(i, scoreEntry);
		
		writeScoreEntries(scoreEntries);
	}
	
}
