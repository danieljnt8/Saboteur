package fop.model.board;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

import fop.model.cards.CardAnchor;
import fop.model.cards.GoalCard;
import fop.model.cards.PathCard;
import fop.model.graph.Edge;
import fop.model.graph.Graph;

/**
 * 
 * Stellt das Wegelabyrinth als Liste von Karten und als Graph dar.
 *
 */
public class Gameboard {
	
	protected final Map<Position, PathCard> board = new HashMap<>();
	protected final Graph<BoardAnchor> graph = new Graph<>();
	
	/**
	 * Erstellt ein leeres Wegelabyrinth und platziert Start- sowie Zielkarten.
	 */
	public Gameboard() {
		clear();
	}
	
	/**
	 * Zum Debuggen kann hiermit der Graph ausgegeben werden.<br>
	 * Auf {@code http://webgraphviz.com/} kann der Code dargestellt werden.
	 */
	public void printGraph() {
		graph.toDotCode().forEach(System.out::println);
	}
	
	/**
	 * Leert das Wegelabyrinth.
	 */
	public void clear() {
		board.clear();
		graph.clear();
	}
	
	// add, remove //
	
	/**
	 * Setzt eine neue Wegekarte in das Wegelabyrinth.<br>
	 * Verbindet dabei alle Kanten des Graphen zu benachbarten Karten,
	 * sofern diese einen Knoten an der benachbarten Stelle besitzen.
	 * @param x x-Position im Wegelabyrinth
	 * @param y y-Position im Wegelabyrinth
	 * @param card die zu platzierende Wegekarte
	 */
	public void placeCard(int x, int y, PathCard card) {
		// add card to list of cards
		board.put(Position.of(x, y), card);
		
		// add vertices inside card to graph
		for (CardAnchor vertex : card.getGraph().vertices())
			graph.addVertex(BoardAnchor.of(x, y, vertex));
		
		// add edges inside card to graph
		for (Edge<CardAnchor> edge : card.getGraph().edges())
			graph.addEdge(BoardAnchor.of(x, y, edge.x()), BoardAnchor.of(x, y, edge.y()));
		
		// add edges to adjacent cards to graph
		for (CardAnchor vertex : card.getGraph().vertices()) {
			Position neighborPosition = vertex.getAdjacentPosition(Position.of(x, y));
			CardAnchor neighborAnchor = vertex.getOppositeAnchor();
			BoardAnchor neighbor = BoardAnchor.of(neighborPosition, neighborAnchor);
			if (graph.hasVertex(neighbor))
				graph.addEdge(BoardAnchor.of(x, y, vertex), neighbor);
		}
		
		// check for goal cards
		checkGoalCards();
	}
	
	/**
	 * Prüft, ob eine Zielkarte erreichbar ist und dreht diese gegebenenfalls um.
	 */
	private void checkGoalCards() {
		for (Entry<Position, PathCard> goal : board.entrySet().stream().filter(e -> e.getValue().isGoalCard()).collect(Collectors.toList())) {
			int x = goal.getKey().x();
			int y = goal.getKey().y();
			if (existsPathFromStartCard(x, y)) {
				GoalCard goalCard = (GoalCard) goal.getValue();
				if (goalCard.isCovered()) {
					// turn card
					goalCard.showFront();
					// generate graph to match all neighbor cards
					goalCard.generateGraph(card -> doesCardMatchItsNeighbors(x, y, card));
					// connect graph of card
					placeCard(x, y, goalCard);
				}
			}
		}
		
	}
	
	/**
	 * Entfernt die Wegekarte an der übergebenen Position.
	 * @param x x-Position im Wegelabyrinth
	 * @param y y-Position im Wegelabyrinth
	 * @return die Karte, die an der Position lag
	 */
	public PathCard removeCard(int x, int y) {
		PathCard oldCard = board.remove(Position.of(x, y));
		for (CardAnchor anchor : CardAnchor.values())
			graph.removeVertex(BoardAnchor.of(x, y, anchor));
		return oldCard;
	}
	
	
	// can //
	
	/**
	 * Gibt genau dann {@code true} zurück, wenn die übergebene Karte an der übergebene Position platziert werden kann.
	 * @param x x-Position im Wegelabyrinth
	 * @param y y-Position im Wegelabyrinth
	 * @param card die zu testende Karte
	 * @return {@code true}, wenn die Karte dort platziert werden kann; sonst {@code false}
	 */
	public boolean canCardBePlacedAt(int x, int y, PathCard card) {
		return isPositionEmpty(x, y) && existsPathFromStartCard(x, y) && doesCardMatchItsNeighbors(x, y, card);
	}
	
	/**
	 * Gibt genau dann {@code true} zurück, wenn auf der übergebenen Position keine Karte liegt.
	 * @param x x-Position im Wegelabyrinth
	 * @param y y-Position im Wegelabyrinth
	 * @return {@code true}, wenn der Platz frei ist; sonst {@code false}
	 */
	private boolean isPositionEmpty(int x, int y) {
		return !board.containsKey(Position.of(x, y));
	}
	
	/**
	 * Gibt genau dann {@code true} zurück, wenn die übergebene Position von einer Startkarte aus erreicht werden kann.
	 * @param x x-Position im Wegelabyrinth
	 * @param y y-Position im Wegelabyrinth
	 * @return {@code true}, wenn die Position erreichbar ist; sonst {@code false}
	 */
	private boolean existsPathFromStartCard(int x, int y) {
		// Vorlage, damit nicht direkt das Spiel beendet ist; entspricht isPositionEmpty, daher etwas kryptisch
		// return board.computeIfAbsent(CardAnchor.left.getAdjacentPosition(Position.of(x + 1, y)), p -> null) == null;
		
		// check every possible start card
		Set<Position> startCardPositions = board.entrySet().stream()
				.filter(e -> e.getValue().isStartCard()).map(e -> e.getKey()).collect(Collectors.toSet());
		for (Position startCardPosition : startCardPositions) {
			
			// check every anchor position of the start card
			Set<BoardAnchor> startCardAnchorPositions = graph.vertices().stream()
					.filter(ap -> ap.x() == startCardPosition.x() && ap.y() == startCardPosition.y()).collect(Collectors.toSet());
			for (BoardAnchor startCardAnchorPosition : startCardAnchorPositions)
				
				// check every possible anchor
				for (CardAnchor anchor : CardAnchor.values()) {
					
					// calculate anchor position of neighbor of the given position
					BoardAnchor anchorPosition = BoardAnchor.of(anchor.getAdjacentPosition(Position.of(x, y)), anchor.getOppositeAnchor());
					
					// check if path from start to goal exists
					if (graph.hasPath(startCardAnchorPosition, anchorPosition))
						return true;
				}
		}
		
		// no path found, return false
		return false;
		
		// == Alternative == //
		//@formatter:off
		/*
		return board.entrySet().stream() // check every card on board
				.filter(p_c -> p_c.getValue().isStartCard()) // find all start cards
				.anyMatch(p_c -> { // check if any start card has a path
					PathCard startCard = p_c.getValue(); // get start card from entry
					Position startCardPosition = p_c.getKey(); // get position of start card from entry
					return startCard.getGraph().vertices().stream() // check every anchor of this start card
							.map(a -> AnchorPosition.of(startCardPosition, a)) // convert card anchor to anchor position
							.anyMatch(startCardAnchorPosition -> Arrays.stream(CardAnchor.values()) // check every possible end anchor
									.map(a -> AnchorPosition.of(a.getAdjacentPosition(Position.of(x, y)), a.getOppositeAnchor())) // convert card anchor to anchor position
									.anyMatch(anchorPosition -> graph.hasPath(startCardAnchorPosition, anchorPosition))); // check if a path exists
				});
		*/
		//@formatter:on
	}
	
	/**
	 * Gibt genau dann {@code true} zurück, wenn die übergebene Karte an der übergebene Position zu ihren Nachbarn passt.
	 * @param x x-Position im Wegelabyrinth
	 * @param y y-Position im Wegelabyrinth
	 * @param card die zu testende Karte
	 * @return {@code true}, wenn die Karte dort zu ihren Nachbarn passt; sonst {@code false}
	 */
	private boolean doesCardMatchItsNeighbors(int x, int y, PathCard card) {
		// check every possible anchor to check every neighbor
		for (CardAnchor anchor : CardAnchor.values()) {
			
			// get corresponding neighbor position
			Position neighborPosition = anchor.getAdjacentPosition(Position.of(x, y));
			
			// check if neighbor exists
			PathCard neighbor = board.get(neighborPosition);
			if (neighbor == null) continue;
			
			// skip if neighbor is a covered goal card
			if (neighbor.isGoalCard() && ((GoalCard) neighbor).isCovered()) continue;
			
			// if the given card has this anchor, the neighbor card has to have an corresponding anchor as well
			if (card.getGraph().hasVertex(anchor)) {
				CardAnchor neededAnchor = anchor.getOppositeAnchor();
				if (neighbor.getGraph().vertices().stream().noneMatch(a -> neededAnchor == a))
					return false;
			}
			
			// if the given card does not have this anchor, the neighbor card must not have an corresponding anchor
			else {
				CardAnchor illegalAnchor = anchor.getOppositeAnchor();
				if (neighbor.getGraph().vertices().stream().anyMatch(a -> illegalAnchor == a))
					return false;
			}
		}
		
		// no problem found, return true
		return true;
		
		// == Alternative == //
		//@formatter:off
		/*
		return Arrays.stream(CardAnchor.values()) // check every possible anchor for the given card
				.map(a -> new Object[] {a, a.getAdjacentPosition(Position.of(x, y))}) // collect position the anchor points to
				.filter(a_p -> board.containsKey(a_p[1])) // check that there is a card
				.map(a_p -> new Object[] {a_p[0], board.get(a_p[1])}) // collect the card at that position
				.filter(a_c -> !(((PathCard) a_c[1]).isGoalCard() && ((GoalCard) a_c[1]).isCovered())) // check that is is not a covered goal card
				.noneMatch(a_c -> { // check whether there is a problem
					CardAnchor anchor = (CardAnchor) a_c[0]; // extract anchor from array
					PathCard neighborCard = (PathCard) a_c[1]; // extract neighbor card from array
					// check whether the card has an anchor and the neighbor has not or vice versa
					return card.getGraph().hasVertex(anchor) ^ neighborCard.getGraph().vertices().stream().anyMatch(ca -> anchor.getOppositeAnchor() == ca);
				});
		*/
		//@formatter:on
	}
	
	/**
	 * Gibt genau dann {@code true} zurück, wenn eine aufgedeckte Goldkarte im Wegelabyrinth liegt.
	 * @return {@code true} wenn eine Goldkarte aufgedeckt ist; sonst {@code false}
	 */
	public boolean isGoldCardVisible() {
		return board.values().stream().anyMatch(c -> c.isGoalCard() && ((GoalCard) c).getType() == GoalCard.Type.Gold && !((GoalCard) c).isCovered());
	}
	
	
	// get //
	
	public Map<Position, PathCard> getBoard() {
		return board;
	}
	
	public int getNumberOfAdjacentCards(int x, int y) {
		Set<Position> neighborPositions = Set.of(Position.of(x - 1, y), Position.of(x + 1, y), Position.of(x, y - 1), Position.of(x, y + 1));
		return (int) board.keySet().stream().filter(pos -> neighborPositions.contains(pos)).count();
	}
	
}
