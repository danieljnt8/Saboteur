package fop.model.cards;

/**
 * 
 * Stellt alle Arten von Werkzeugen dar.
 *
 */
public enum ToolType {
	lantern, mine_cart, pick;
}
