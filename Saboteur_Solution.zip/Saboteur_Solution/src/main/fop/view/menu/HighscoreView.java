package fop.view.menu;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.function.Consumer;

import fop.io.ScoreEntryIO;
import fop.model.ScoreEntry;
import fop.view.MainFrame;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

@SuppressWarnings("serial")
public class HighscoreView extends MenuView {
	
	private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");
	
	private JTable scores;
	
	public HighscoreView(MainFrame window) {
		super(window, "Highscores");
	}
	
	@Override
	protected void addContent(JPanel contentPanel) {
		contentPanel.setLayout(new GridBagLayout());
		
		// Highscore table //
		GridBagConstraints tableConstraints = new GridBagConstraints();
		tableConstraints.weightx = 1.0;
		tableConstraints.weighty = 1.0;
		tableConstraints.fill = GridBagConstraints.BOTH;
		tableConstraints.insets = new Insets(0, 2, 2, 2);
		tableConstraints.gridx = 0;
		tableConstraints.gridy = 0;
		DefaultTableModel tableModel = new DefaultTableModel() {
			
			private List<String> columnNames = List.of("Datum und Uhrzeit", "Name", "Punkte");
			
			@Override
			public String getColumnName(int columnIndex) {
				return columnNames.get(columnIndex);
			}
			
			@Override
			public int getColumnCount() {
				return columnNames.size();
			}
			
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
			
		};
		scores = new JTable(tableModel);
		scores.setColumnSelectionAllowed(false);
		scores.setRowSelectionAllowed(false);
		scores.getTableHeader().setReorderingAllowed(false);
		for (ScoreEntry scoreEntry : ScoreEntryIO.loadScoreEntries())
			tableModel.addRow(new Object[] {
					scoreEntry.getDateTime().format(DATE_TIME_FORMATTER),
					scoreEntry.getName(),
					scoreEntry.getScore()
			});
		
		contentPanel.add(new JScrollPane(scores), tableConstraints);
		
		// back button //
		GridBagConstraints rightImageConstraints = new GridBagConstraints();
		rightImageConstraints.insets = new Insets(2, 2, 0, 2);
		rightImageConstraints.gridx = 0;
		rightImageConstraints.gridy = 1;
		JButton backButton = createButton("Zurück");
		backButton.addActionListener(evt -> getWindow().setView(new MainMenu(getWindow())));
		contentPanel.add(backButton, rightImageConstraints);
	}
	
	@Override
	public void onResize() {
		super.onResize();
		int size = Math.min(getWidth(), getHeight());
		Consumer<JComponent> resize = comp -> comp.setFont(comp.getFont().deriveFont(size / 30f));
		
		resize.accept(scores);
		resize.accept(scores.getTableHeader());
		
		JLabel label = new JLabel("-");
		label.setFont(scores.getFont());
		scores.setRowHeight(label.getPreferredSize().height);
	}
	
}
