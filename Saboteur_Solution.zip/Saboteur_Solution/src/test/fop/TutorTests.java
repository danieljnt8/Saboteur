package fop;

import static fop.model.cards.CardAnchor.bottom;
import static fop.model.cards.CardAnchor.left;
import static fop.model.cards.CardAnchor.right;
import static fop.model.cards.CardAnchor.top;
import static org.junit.jupiter.api.Assertions.*;

import java.io.*;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.FileSystemException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import fop.io.CardImageReader;
import fop.io.PathCardReader;
import fop.io.ScoreEntryIO;
import fop.model.Player.Role;
import fop.model.ScoreEntry;
import fop.model.board.BoardAnchor;
import fop.model.board.Gameboard;
import fop.model.board.Position;
import fop.model.cards.CardAnchor;
import fop.model.cards.GoalCard;
import fop.model.cards.PathCard;
import fop.model.cards.StartCard;
import fop.model.graph.Edge;
import fop.model.graph.Graph;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer.Alphanumeric;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;

@TestMethodOrder(Alphanumeric.class)
@SuppressWarnings({"unchecked", "javadoc"})
@DisplayName("FOP Projekt 20/21")
public final class TutorTests {
	
	/*
	 * ~~~ README ~~~
	 * Diese Tests testen die Aufgaben 4.1 und 4.2 sowie einen Testfall von Aufgabe 4.3.2.
	 * Es gibt für jeden Punkt auf dem Bewertungsschema genau einen Testfall.
	 * Tests, für die definitiv in den Code geschaut werden muss, sind mit [*] markiert.
	 * Tests, für die eventuell in den Code geschaut werden muss, sind mit (*) markiert.
	 * Wenn in den Code geschaut werden muss, wird ein entsprechender Fehler geworfen
	 * und dann sind die wichtigsten Infos sind in der Fehlerbeschreibung zu finden.
	 * (Generell sollte immer wenigstens ein kurzer Blick in den Code geworfen werden.)
	 * ~~~~~~~~~~~~~~
	 */
	
	private TutorTests() {}
	
	private static Object getAttribute(Object object, String name) {
		try {
			Class<?> clazz = object.getClass();
			while (Arrays.stream(clazz.getDeclaredFields()).noneMatch(f -> f.getName().equals(name)))
				clazz = clazz.getSuperclass();
			Field field = clazz.getDeclaredField(name);
			field.setAccessible(true);
			return field.get(object);
		} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
			fail("Reflection failed");
			return null;
		}
	}
	
	public static Object getStaticAttribute(Class<?> clazz, String name) {
		try {
			while (Arrays.stream(clazz.getDeclaredFields()).noneMatch(f -> f.getName().equals(name)))
				clazz = clazz.getSuperclass();
			Field field = clazz.getDeclaredField(name);
			field.setAccessible(true);
			return field.get(null);
		} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
			fail("Reflection failed");
			return null;
		}
	}
	
	public static void setAttribute(Object object, String name, Object value) {
		try {
			Class<?> clazz = object.getClass();
			while (Arrays.stream(clazz.getDeclaredFields()).noneMatch(f -> f.getName().equals(name)))
				clazz = clazz.getSuperclass();
			Field field = clazz.getDeclaredField(name);
			field.setAccessible(true);
			field.set(object, value);
		} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
			e.printStackTrace();
			fail("Reflection failed");
		}
	}
	
	public static void setStaticAttribute(Class<?> clazz, String name, Object value) {
		try {
			Field field = clazz.getDeclaredField(name);
			field.setAccessible(true);
			field.set(null, value);
		} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
			e.printStackTrace();
			fail("Reflection failed");
		}
	}
	
	private static Object callMethod(Object object, String name, Object... parameters) throws Exception {
		try {
			Method method = Arrays.stream(object.getClass().getDeclaredMethods()).filter(m -> m.getName().equals(name)).findFirst().get();
			method.setAccessible(true);
			return method.invoke(object, parameters);
		} catch (IllegalArgumentException | SecurityException | IllegalAccessException e) {
			fail("Reflection failed");
			return null;
		} catch (InvocationTargetException e) {
			// Method failed, Exception weitergeben
			throw (Exception) e.getCause();
		}
	}
	
	private static <E> Set<E> newSet(E... elements) {
		return new HashSet<>(Set.of(elements));
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	//===========================================================================================//
	//===========================================================================================//
	///////////////////////////////////////////////////////////////////////////////////////////////
	
	@Nested
	@DisplayName("Aufgabe 4.1")
	public class A1 {
		
		@Nested
		@DisplayName("Aufgabe 4.1.1")
		public class A11 {
			
			public A11() {}
			
			/**
			 * {@link fop.model.graph.Graph#addVertex(Object)}
			 */
			@Test
			@DisplayName("addVertex")
			public void m1() {
				Graph<Integer> graph = new Graph<Integer>() {
					@Override
					public boolean addEdge(Integer x, Integer y) {
						if (!hasVertex(x)) G.put(x, new HashSet<>());
						if (!hasVertex(y)) G.put(y, new HashSet<>());
						if (G.get(x).contains(y)) return false;
						G.get(x).add(y);
						G.get(y).add(x);
						return true;
					}
					@Override
					public boolean removeVertex(Integer v) {
						boolean b = G.remove(v) != null;
						for (Integer w : vertices())
							G.get(w).remove(v);
						return b;
					}
					@Override
					public boolean removeEdge(Integer x, Integer y) {
						if (!hasEdge(x, y)) return false;
						G.get(x).remove(y);
						G.get(y).remove(x);
						return true;
					}
					@Override
					public boolean hasPath(Integer x, Integer y) {
						if (x.equals(y)) return true;
						if (!hasVertex(x) || !hasVertex(y)) return false;
						Map<Integer, Integer> d = new HashMap<>();
						for (Integer v : vertices())
							d.put(v, Integer.MAX_VALUE);
						d.put(x, 0);
						Queue<Integer> Q = new LinkedList<>();
						Q.add(x);
						while (!Q.isEmpty()) {
							Integer u = Q.remove();
							for (Integer v : getAdjacentVertices(u))
								if (d.get(v) == Integer.MAX_VALUE) {
									if (v.equals(y)) return true;
									d.put(v, d.get(u) + 1);
									Q.add(v);
								}
						}
						return false;
					}
				};
				
				// Knoten hinzufügen
				graph.addVertex(42);
				assertEquals(newSet(42), graph.vertices(), "Knoten werden nicht hinzugefügt.");
				graph.addVertex(43);
				assertEquals(newSet(42, 43), graph.vertices(), "Knoten werden nicht hinzugefügt.");
				graph.addVertex(99);
				assertEquals(newSet(42, 43, 99), graph.vertices(), "Knoten werden nicht hinzugefügt.");
				
				// Bereits existierende Knoten hinzufügen
				graph.addVertex(43);
				assertEquals(newSet(42, 43, 99), graph.vertices(), "Probleme bei bereits hinzugefügten Knoten");
				
				// Bereits verbundene Kanten NICHT entfernen
				Map<Integer, Set<Integer>> G = (Map<Integer, Set<Integer>>) getAttribute(graph, "G");
				G.put(99, newSet(42));
				G.put(42, newSet(99));
				graph.addVertex(99);
				assertEquals(newSet(42, 43, 99), graph.vertices(), "Probleme bei bereits hinzugefügten Knoten");
				assertEquals(newSet(42), graph.getAdjacentVertices(99), "Bereits verbundene Kanten werden entfernt");
			}
			
			/**
			 * {@link fop.model.graph.Graph#addEdge(Object, Object)}
			 */
			@Test
			@DisplayName("addEdge")
			public void m2() {
				Graph<Integer> graph = new Graph<>() {
					@Override
					public void addVertex(Integer v) {
						if (hasVertex(v)) return;
						G.put(v, new HashSet<>());
					}
					@Override
					public boolean removeVertex(Integer v) {
						boolean b = G.remove(v) != null;
						for (Integer w : vertices())
							G.get(w).remove(v);
						return b;
					}
					@Override
					public boolean removeEdge(Integer x, Integer y) {
						if (!hasEdge(x, y)) return false;
						G.get(x).remove(y);
						G.get(y).remove(x);
						return true;
					}
					@Override
					public boolean hasPath(Integer x, Integer y) {
						if (x.equals(y)) return true;
						if (!hasVertex(x) || !hasVertex(y)) return false;
						Map<Integer, Integer> d = new HashMap<>();
						for (Integer v : vertices())
							d.put(v, Integer.MAX_VALUE);
						d.put(x, 0);
						Queue<Integer> Q = new LinkedList<>();
						Q.add(x);
						while (!Q.isEmpty()) {
							Integer u = Q.remove();
							for (Integer v : getAdjacentVertices(u))
								if (d.get(v) == Integer.MAX_VALUE) {
									if (v.equals(y)) return true;
									d.put(v, d.get(u) + 1);
									Q.add(v);
								}
						}
						return false;
					}
				};
				
				// Benötigte Knoten automatisch hinzufügen
				// Beide Kanten hinzufügen
				boolean b = graph.addEdge(3, 4);
				assertEquals(newSet(3, 4), graph.vertices(), "Benötigte Knoten werden nicht automatisch hinzugefügt");
				assertEquals(newSet(4), graph.getAdjacentVertices(3), "Die Kante von x zu y wird nicht hinzugefügt");
				assertEquals(newSet(3), graph.getAdjacentVertices(4), "Die Kante von y zu x wird nicht hinzugefügt (ungerichteter Graph)");
				assertTrue(b, "Rückgabewert ist falsch");
				
				// Auch nur eine benötigte Kante hinzufügen
				b = graph.addEdge(3, 5);
				assertEquals(newSet(3, 4, 5), graph.vertices(), "Benötigte Knoten werden nicht automatisch hinzugefügt");
				assertEquals(newSet(4, 5), graph.getAdjacentVertices(3), "Die Kante von x zu y wird nicht hinzugefügt");
				assertEquals(newSet(3), graph.getAdjacentVertices(5), "Die Kante von y zu x wird nicht hinzugefügt (ungerichteter Graph)");
				assertEquals(newSet(3), graph.getAdjacentVertices(4), "Es wird die Adjazenzliste eines Knotens, der nicht x oder y ist, verändert");
				assertTrue(b, "Rückgabewert ist falsch");
				
				// Kante vorhanden, false zurückgeben
				b = graph.addEdge(4, 3);
				assertEquals(newSet(3, 4, 5), graph.vertices(), "Probleme bei bereits bestehenden Kanten");
				assertEquals(newSet(4, 5), graph.getAdjacentVertices(3), "Probleme bei bereits bestehenden Kanten");
				assertEquals(newSet(3), graph.getAdjacentVertices(4), "Probleme bei bereits bestehenden Kanten");
				assertEquals(newSet(3), graph.getAdjacentVertices(5), "Es wird die Adjazenzliste eines Knotens, der nicht x oder y ist, verändert");
				assertFalse(b, "Rückgabewert bei bereits bestehenden Kanten ist falsch");
			}
			
			/**
			 * {@link fop.model.graph.Graph#removeVertex(Object)}
			 */
			@Test
			@DisplayName("removeVertex")
			public void m3() {
				Graph<String> graph = new Graph<>() {
					@Override
					public void addVertex(String v) {
						if (hasVertex(v)) return;
						G.put(v, new HashSet<>());
					}
					@Override
					public boolean addEdge(String x, String y) {
						if (!hasVertex(x)) G.put(x, new HashSet<>());
						if (!hasVertex(y)) G.put(y, new HashSet<>());
						if (G.get(x).contains(y)) return false;
						G.get(x).add(y);
						G.get(y).add(x);
						return true;
					}
					@Override
					public boolean removeEdge(String x, String y) {
						if (!hasEdge(x, y)) return false;
						G.get(x).remove(y);
						G.get(y).remove(x);
						return true;
					}
					@Override
					public boolean hasPath(String x, String y) {
						if (x.equals(y)) return true;
						if (!hasVertex(x) || !hasVertex(y)) return false;
						Map<String, Integer> d = new HashMap<>();
						for (String v : vertices())
							d.put(v, Integer.MAX_VALUE);
						d.put(x, 0);
						Queue<String> Q = new LinkedList<>();
						Q.add(x);
						while (!Q.isEmpty()) {
							String u = Q.remove();
							for (String v : getAdjacentVertices(u))
								if (d.get(v) == Integer.MAX_VALUE) {
									if (v.equals(y)) return true;
									d.put(v, d.get(u) + 1);
									Q.add(v);
								}
						}
						return false;
					}
				};
				graph.addEdge("a", "b");
				graph.addEdge("b", "c");
				graph.addVertex("d");
				
				// Entferne Knoten ohne Kanten
				boolean b = graph.removeVertex("d");
				assertEquals(newSet("a", "b", "c"), graph.vertices(), "Der Knoten wird nicht entfernt");
				assertEquals(newSet("b"), graph.getAdjacentVertices("a"), "Es wird ein Knoten, der nicht v ist, geändert");
				assertEquals(newSet("a", "c"), graph.getAdjacentVertices("b"), "Es wird ein Knoten, der nicht v ist, geändert");
				assertEquals(newSet("b"), graph.getAdjacentVertices("c"), "Es wird ein Knoten, der nicht v ist, geändert");
				assertTrue(b, "Rückgabewert ist falsch");
				
				// Keinen Knoten entfernen
				b = graph.removeVertex("d");
				assertEquals(newSet("a", "b", "c"), graph.vertices(), "Beim Entfernen eines nicht vorhandenen Knotens wird der Graph geändert");
				assertEquals(newSet("b"), graph.getAdjacentVertices("a"), "Es wird ein Knoten, der nicht v ist, geändert");
				assertEquals(newSet("a", "c"), graph.getAdjacentVertices("b"), "Es wird ein Knoten, der nicht v ist, geändert");
				assertEquals(newSet("b"), graph.getAdjacentVertices("c"), "Es wird ein Knoten, der nicht v ist, geändert");
				assertFalse(b, "Rückgabewert bei nicht vorhandenen Knoten ist falsch");
				
				// Knoten mit allen verbundenen Kanten entfernen
				b = graph.removeVertex("b");
				assertEquals(newSet("a", "c"), graph.vertices(), "Der Knoten wird nicht entfernt");
				assertEquals(newSet(), graph.getAdjacentVertices("a"),
						"Die Kante in der Adjazenzliste des mit der benachbarten Kante verbundenen Knotens wird nicht entfernt");
				assertEquals(newSet(), graph.getAdjacentVertices("c"),
						"Die Kante in der Adjazenzliste des mit der benachbarten Kante verbundenen Knotens wird nicht entfernt");
				assertTrue(b, "Rückgabewert ist falsch");
			}
			
			/**
			 * {@link fop.model.graph.Graph#removeEdge(Object, Object)}
			 */
			@Test
			@DisplayName("removeEdge")
			public void m4() {
				Graph<String> graph = new Graph<>() {
					@Override
					public void addVertex(String v) {
						if (hasVertex(v)) return;
						G.put(v, new HashSet<>());
					}
					@Override
					public boolean addEdge(String x, String y) {
						if (!hasVertex(x)) G.put(x, new HashSet<>());
						if (!hasVertex(y)) G.put(y, new HashSet<>());
						if (G.get(x).contains(y)) return false;
						G.get(x).add(y);
						G.get(y).add(x);
						return true;
					}
					@Override
					public boolean removeVertex(String v) {
						boolean b = G.remove(v) != null;
						for (String w : vertices())
							G.get(w).remove(v);
						return b;
					}
					@Override
					public boolean hasPath(String x, String y) {
						if (x.equals(y)) return true;
						if (!hasVertex(x) || !hasVertex(y)) return false;
						Map<String, Integer> d = new HashMap<>();
						for (String v : vertices())
							d.put(v, Integer.MAX_VALUE);
						d.put(x, 0);
						Queue<String> Q = new LinkedList<>();
						Q.add(x);
						while (!Q.isEmpty()) {
							String u = Q.remove();
							for (String v : getAdjacentVertices(u))
								if (d.get(v) == Integer.MAX_VALUE) {
									if (v.equals(y)) return true;
									d.put(v, d.get(u) + 1);
									Q.add(v);
								}
						}
						return false;
					}
				};
				graph.addEdge("a", "b");
				graph.addEdge("b", "c");
				graph.addVertex("d");
				
				// Entferne Kante
				// Korrekter Rückgabewert
				boolean b = graph.removeEdge("a", "b");
				assertEquals(newSet("a", "b", "c", "d"), graph.vertices(), "Es wird ein Knoten entfernt oder hinzugefügt");
				assertEquals(newSet(), graph.getAdjacentVertices("a"), "Die Kante wird nicht in der Adjazenzliste von x entfernt");
				assertEquals(newSet("c"), graph.getAdjacentVertices("b"), "Die Kante wird nicht in der Adjazenzliste von x entfernt (ungerichteter Graph)");
				assertEquals(newSet("b"), graph.getAdjacentVertices("c"), "Es wird ein Knoten, der nicht x oder y ist, geändert");
				assertTrue(b, "Rückgabewert ist falsch");
				
				// Keine Kante zwischen vorhandenen Knoten vorhanden
				// Korrekter Rückgabewert
				b = graph.removeEdge("a", "b");
				assertEquals(newSet("a", "b", "c", "d"), graph.vertices(), "Es wird ein Knoten entfernt oder hinzugefügt");
				assertEquals(newSet(), graph.getAdjacentVertices("a"), "Die Adjazenzliste von x wird geändert, obwohl keine Kante entfernt werden soll");
				assertEquals(newSet("c"), graph.getAdjacentVertices("b"), "Die Adjazenzliste von y wird geändert, obwohl keine Kante entfernt werden soll");
				assertEquals(newSet("b"), graph.getAdjacentVertices("c"), "Es wird ein Knoten, der nicht x oder y ist, geändert");
				assertFalse(b, "Rückgabewert beim Entfernen von nicht vorhandenen Kanten ist falsch");
				
				// Kante von NICHT vorhandenen Knoten entfernen
				b = graph.removeEdge("nicht vorhanden", "a");
				assertEquals(newSet("a", "b", "c", "d"), graph.vertices(), "Es wird ein Knoten entfernt oder hinzugefügt");
				assertEquals(newSet(), graph.getAdjacentVertices("a"), "Die Adjazenzliste von y wird geändert, obwohl keine Kante entfernt werden soll");
				assertEquals(newSet("c"), graph.getAdjacentVertices("b"), "Es wird ein Knoten, der nicht x oder y ist, geändert");
				assertEquals(newSet("b"), graph.getAdjacentVertices("c"), "Es wird ein Knoten, der nicht x oder y ist, geändert");
				assertFalse(b, "Rückgabewert beim Entfernen mit einem nicht vorhandenen Knoten ist falsch");
			}
			
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		private class TestHasPathGraph<V> extends Graph<V> {
			@Override
			public void addVertex(V v) {
				if (hasVertex(v)) return;
				G.put(v, new HashSet<>());
			}
			@Override
			public boolean addEdge(V x, V y) {
				if (!hasVertex(x)) G.put(x, new HashSet<>());
				if (!hasVertex(y)) G.put(y, new HashSet<>());
				if (G.get(x).contains(y)) return false;
				G.get(x).add(y);
				G.get(y).add(x);
				return true;
			}
			@Override
			public boolean removeVertex(V v) {
				boolean b = G.remove(v) != null;
				for (V w : vertices())
					G.get(w).remove(v);
				return b;
			}
			@Override
			public boolean removeEdge(V x, V y) {
				if (!hasEdge(x, y)) return false;
				G.get(x).remove(y);
				G.get(y).remove(x);
				return true;
			}
		}
		
		@Nested
		@DisplayName("Aufgabe 4.1.2")
		public class A12 {
			
			public A12() {}
			
			/**
			 * {@link fop.model.graph.Graph#hasPath(Object, Object)}
			 */
			@Test
			@DisplayName("direkte Nachbarn")
			public void m1() {
				/*
				 * A -- B -- C
				 * |
				 * D -- E
				 * 
				 * F
				 */
				Graph<String> graph = new TestHasPathGraph<>();
				graph.addEdge("A", "B");
				graph.addEdge("A", "D");
				graph.addEdge("B", "C");
				graph.addEdge("D", "E");
				graph.addVertex("F");
				
				// X -- Y => true
				String s = "Pfade zu direkten Nachbarn werden nicht gefunden";
				assertTrue(graph.hasPath("A", "B"), s);
				assertTrue(graph.hasPath("B", "A"), s);
				assertTrue(graph.hasPath("B", "C"), s);
				assertTrue(graph.hasPath("C", "B"), s);
				assertTrue(graph.hasPath("A", "D"), s);
				assertTrue(graph.hasPath("D", "A"), s);
				assertTrue(graph.hasPath("D", "E"), s);
				assertTrue(graph.hasPath("E", "D"), s);
				
				// X -- Y => false
				s = "Es werden nicht existierende Pfade gefunden";
				assertFalse(graph.hasPath("A", "F"), s);
				assertFalse(graph.hasPath("B", "F"), s);
				assertFalse(graph.hasPath("C", "F"), s);
				assertFalse(graph.hasPath("D", "F"), s);
				assertFalse(graph.hasPath("E", "F"), s);
				assertFalse(graph.hasPath("F", "A"), s);
				assertFalse(graph.hasPath("F", "B"), s);
				assertFalse(graph.hasPath("F", "C"), s);
				assertFalse(graph.hasPath("F", "D"), s);
				assertFalse(graph.hasPath("F", "E"), s);
			}
			
			/**
			 * {@link fop.model.graph.Graph#hasPath(Object, Object)}
			 */
			@Test
			@DisplayName("mit Zyklen")
			public void m2() {
				/*
				 * A - B - C
				 * | X |
				 * D - E
				 * 
				 * F
				 */
				Graph<String> graph = new TestHasPathGraph<>();
				graph.addEdge("A", "B");
				graph.addEdge("A", "D");
				graph.addEdge("A", "E");
				graph.addEdge("B", "C");
				graph.addEdge("B", "D");
				graph.addEdge("B", "E");
				graph.addEdge("D", "E");
				graph.addVertex("F");
				
				// X -- Y => true
				String timeout = "Die Methode terminiert bei zyklischen Graphen nicht";
				for (String x : "ABCDE".split(""))
					for (String y : "ABCDE".split("")) {
						if (x.equals(y)) continue; // skip where x == y
						assertTimeout(Duration.ofSeconds(3),
								() -> assertTrue(graph.hasPath(x, y), "Pfade in zyklischen Graphen werden nicht gefunden"),
								timeout);
					}
				
				// X -- Y => false
				String s = "Es werden nicht existierende Pfade gefunden";
				for (String v : "ABCDE".split("")) {
					assertTimeout(Duration.ofSeconds(3), () -> assertFalse(graph.hasPath(v, "F"), s), timeout);
					assertTimeout(Duration.ofSeconds(3), () -> assertFalse(graph.hasPath("F", v), s), timeout);
				}
			}
			
			/**
			 * {@link fop.model.graph.Graph#hasPath(Object, Object)}
			 */
			@Test
			@DisplayName("Sonderfälle")
			public void m3() {
				/*
				 * A -- B
				 * 
				 * C
				 */
				Graph<String> graph = new TestHasPathGraph<>();
				graph.addEdge("A", "B");
				graph.addVertex("C");
				
				// nicht vorhandene Knoten
				String timeout = "Die Methode terminiert nicht, wenn nach nicht vorhandenen Knoten gesucht wird";
				assertTimeout(Duration.ofSeconds(3), () -> assertFalse(graph.hasPath("A", "nicht vorhanden")), timeout);
				assertTimeout(Duration.ofSeconds(3), () -> assertFalse(graph.hasPath("nicht vorhanden", "B")), timeout);
				assertTimeout(Duration.ofSeconds(3), () -> assertFalse(graph.hasPath("nicht", "vorhanden")), timeout);
				
				// Startknoten = Zielknoten
				assertTrue(graph.hasPath("A", "A"));
				assertTrue(graph.hasPath("B", "B"));
				assertTrue(graph.hasPath("C", "C"));
			}
			
			/**
			 * {@link fop.model.graph.Graph#hasPath(Object, Object)}
			 */
			@Test
			@DisplayName("vollständig korrekt")
			public void m4() {
				// @formatter:off
				/*
				 * ----------------
				 * |         |    |
				 * A -- B -- C -- D
				 * |         |
				 * E -- F ----
				 * |
				 * G
				 * 
				 * H -- I -- J -- K
				 * |         |
				 * L ------- M
				 * 
				 * N
				 */
				// @formatter:on
				
				Graph<String> graph = new TestHasPathGraph<>();
				graph.addEdge("A", "B");
				graph.addEdge("A", "C");
				graph.addEdge("A", "D");
				graph.addEdge("A", "E");
				graph.addEdge("B", "C");
				graph.addEdge("C", "D");
				graph.addEdge("C", "F");
				graph.addEdge("E", "F");
				graph.addEdge("F", "G");
				graph.addEdge("H", "I");
				graph.addEdge("H", "L");
				graph.addEdge("I", "J");
				graph.addEdge("J", "K");
				graph.addEdge("J", "M");
				graph.addEdge("L", "M");
				graph.addVertex("N");
				
				// X -- Y => true
				String sTrue = "Lange Pfade zu werden nicht korrekt gefunden";
				String timeout = "Die Methode terminiert bei zyklischen Graphen nicht";
				for (String x : "ABCDEFG".split(""))
					for (String y : "ABCDEFG".split(""))
						assertTimeout(Duration.ofSeconds(3),
								() -> assertTrue(graph.hasPath(x, y), sTrue),
								timeout);
				for (String x : "HIJKLM".split(""))
					for (String y : "HIJKLM".split(""))
						assertTimeout(Duration.ofSeconds(3),
								() -> assertTrue(graph.hasPath(x, y), sTrue),
								timeout);
					
				// X -- Y => false
				String sFalse = "Es werden nicht existierende Pfade gefunden";
				for (String v : "ABCDEFGHIJKLM".split("")) {
					assertTimeout(Duration.ofSeconds(3), () -> assertFalse(graph.hasPath(v, "N"), sFalse), timeout);
					assertTimeout(Duration.ofSeconds(3), () -> assertFalse(graph.hasPath("N", v), sFalse), timeout);
				}
			}
			
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		@Nested
		@DisplayName("Aufgabe 4.1.3")
		public class A13 {
			
			public A13() {}
			
			private List<PathCard> getCardsByName(String name) {
				return PathCardReader.readFromResource("/pathcards.xml").stream()
						.filter(pc -> pc.getName().matches(name + "(_\\d+)?"))
						.collect(Collectors.toList());
			}
			
			@Test
			@DisplayName("curve_double_down")
			public void m1() {
				List<PathCard> cards = getCardsByName("curve_double_down");
				assertFalse(cards.isEmpty(), "Die Karte wurde nicht definiert");
				assertEquals(1, cards.size(), "count ist falsch");
				for (PathCard card : cards) {
					Graph<CardAnchor> graph = (Graph<CardAnchor>) getAttribute(card, "graph");
					assertEquals(newSet(left, bottom, right, top), graph.vertices(), "Die Knoten sind falsch");
					assertEquals(newSet(bottom), graph.getAdjacentVertices(left), "Die Kanten zum linken Knoten sind falsch");
					assertEquals(newSet(left), graph.getAdjacentVertices(bottom), "Die Kanten zum unteren Knoten sind falsch");
					assertEquals(newSet(top), graph.getAdjacentVertices(right), "Die Kanten zum rechten Knoten sind falsch");
					assertEquals(newSet(right), graph.getAdjacentVertices(top), "Die Kanten zum oberen Knoten sind falsch");
				}
			}
			
			@Test
			@DisplayName("curve_up_dead_bottom")
			public void m2() {
				List<PathCard> cards = getCardsByName("curve_up_dead_bottom");
				assertFalse(cards.isEmpty(), "Die Karte wurde nicht definiert");
				assertEquals(2, cards.size(), "count ist falsch");
				for (PathCard card : cards) {
					Graph<CardAnchor> graph = (Graph<CardAnchor>) getAttribute(card, "graph");
					assertEquals(newSet(left, bottom, top), graph.vertices(), "Die Knoten sind falsch");
					assertEquals(newSet(top), graph.getAdjacentVertices(left), "Die Kanten zum linken Knoten sind falsch");
					assertEquals(newSet(), graph.getAdjacentVertices(bottom), "Die Kanten zum unteren Knoten sind falsch");
					assertEquals(newSet(left), graph.getAdjacentVertices(top), "Die Kanten zum oberen Knoten sind falsch");
				}
			}
			
			@Test
			@DisplayName("line_vert_dead_two")
			public void m3() {
				List<PathCard> cards = getCardsByName("line_vert_dead_two");
				assertFalse(cards.isEmpty(), "Die Karte wurde nicht definiert");
				assertEquals(1, cards.size(), "count ist falsch");
				for (PathCard card : cards) {
					Graph<CardAnchor> graph = (Graph<CardAnchor>) getAttribute(card, "graph");
					assertEquals(newSet(left, bottom, right, top), graph.vertices(), "Die Knoten sind falsch");
					assertEquals(newSet(), graph.getAdjacentVertices(left), "Die Kanten zum linken Knoten sind falsch");
					assertEquals(newSet(top), graph.getAdjacentVertices(bottom), "Die Kanten zum unteren Knoten sind falsch");
					assertEquals(newSet(), graph.getAdjacentVertices(right), "Die Kanten zum rechten Knoten sind falsch");
					assertEquals(newSet(bottom), graph.getAdjacentVertices(top), "Die Kanten zum oberen Knoten sind falsch");
				}
			}
			
			@Test
			@DisplayName("tunnel")
			public void m4() {
				List<PathCard> cards = getCardsByName("tunnel");
				assertFalse(cards.isEmpty(), "Die Karte wurde nicht definiert");
				assertEquals(2, cards.size(), "count ist falsch");
				for (PathCard card : cards) {
					Graph<CardAnchor> graph = (Graph<CardAnchor>) getAttribute(card, "graph");
					assertEquals(newSet(left, bottom, right, top), graph.vertices(), "Die Knoten sind falsch");
					assertEquals(newSet(right), graph.getAdjacentVertices(left), "Die Kanten zum linken Knoten sind falsch");
					assertEquals(newSet(top), graph.getAdjacentVertices(bottom), "Die Kanten zum unteren Knoten sind falsch");
					assertEquals(newSet(left), graph.getAdjacentVertices(right), "Die Kanten zum rechten Knoten sind falsch");
					assertEquals(newSet(bottom), graph.getAdjacentVertices(top), "Die Kanten zum oberen Knoten sind falsch");
				}
			}
			
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		private int randomID() {
			return (int) (Math.random() * 1000) + 1;
		}
		
		private class SolutionGraph<V> extends Graph<V> {
			@Override
			public void clear() {
				G.clear();
			}
			@Override
			public void addVertex(V v) {
				if (hasVertex(v)) return;
				G.put(v, new HashSet<>());
			}
			@Override
			public boolean addEdge(V x, V y) {
				if (!hasVertex(x)) G.put(x, new HashSet<>());
				if (!hasVertex(y)) G.put(y, new HashSet<>());
				if (G.get(x).contains(y)) return false;
				G.get(x).add(y);
				G.get(y).add(x);
				return true;
			}
			@Override
			public boolean removeVertex(V v) {
				boolean b = G.remove(v) != null;
				for (V w : vertices())
					G.get(w).remove(v);
				return b;
			}
			@Override
			public boolean removeEdge(V x, V y) {
				if (!hasEdge(x, y)) return false;
				G.get(x).remove(y);
				G.get(y).remove(x);
				return true;
			}
			@Override
			public boolean hasVertex(V v) {
				return G.containsKey(v);
			}
			@Override
			public boolean hasEdge(V x, V y) {
				return G.containsKey(x) && G.get(x).contains(y);
			}
			@Override
			public boolean hasPath(V x, V y) {
				if (x.equals(y)) return true;
				if (!hasVertex(x) || !hasVertex(y)) return false;
				Map<V, Integer> d = new HashMap<>();
				for (V v : vertices())
					d.put(v, Integer.MAX_VALUE);
				d.put(x, 0);
				Queue<V> Q = new LinkedList<>();
				Q.add(x);
				while (!Q.isEmpty()) {
					V u = Q.remove();
					for (V v : getAdjacentVertices(u))
						if (d.get(v) == Integer.MAX_VALUE) {
							if (v.equals(y)) return true;
							d.put(v, d.get(u) + 1);
							Q.add(v);
						}
				}
				return false;
			}
			@Override
			public Set<V> vertices() {
				return G.keySet();
			}
			@Override
			public Set<V> getAdjacentVertices(V v) {
				return G.get(v);
			}
			@Override
			public Set<Edge<V>> edges() {
				Set<Edge<V>> edges = new HashSet<>();
				G.forEach((x, m) -> m.forEach(y -> {
					edges.add(Edge.of(x, y));
				}));
				return edges;
			}
		}
		
		private PathCard createStart() {
			Graph<CardAnchor> graph = new SolutionGraph<>();
			Map<CardAnchor, Set<CardAnchor>> G = (Map<CardAnchor, Set<CardAnchor>>) getAttribute(graph, "G");
			G.put(left, newSet(bottom, right, top));
			G.put(bottom, newSet(left, right, top));
			G.put(right, newSet(left, bottom, top));
			G.put(top, newSet(left, bottom, right));
			return new StartCard(graph);
		}
		
		private PathCard createPlus() {
			Graph<CardAnchor> graph = new SolutionGraph<>();
			Map<CardAnchor, Set<CardAnchor>> G = (Map<CardAnchor, Set<CardAnchor>>) getAttribute(graph, "G");
			G.put(left, newSet(bottom, right, top));
			G.put(bottom, newSet(left, right, top));
			G.put(right, newSet(left, bottom, top));
			G.put(top, newSet(left, bottom, right));
			return new PathCard("plus_" + randomID(), graph);
		}
		
		private PathCard createDeadPlus() {
			Graph<CardAnchor> graph = new SolutionGraph<>();
			Map<CardAnchor, Set<CardAnchor>> G = (Map<CardAnchor, Set<CardAnchor>>) getAttribute(graph, "G");
			G.put(left, newSet());
			G.put(bottom, newSet());
			G.put(right, newSet());
			G.put(top, newSet());
			return new PathCard("dead_plus_" + randomID(), graph);
		}
		
		private PathCard createLineHoriz() {
			Graph<CardAnchor> graph = new SolutionGraph<>();
			Map<CardAnchor, Set<CardAnchor>> G = (Map<CardAnchor, Set<CardAnchor>>) getAttribute(graph, "G");
			G.put(left, newSet(right));
			G.put(right, newSet(left));
			return new PathCard("line_horiz_" + randomID(), graph);
		}
		
		private PathCard createLineVert() {
			Graph<CardAnchor> graph = new SolutionGraph<>();
			Map<CardAnchor, Set<CardAnchor>> G = (Map<CardAnchor, Set<CardAnchor>>) getAttribute(graph, "G");
			G.put(bottom, newSet(top));
			G.put(top, newSet(bottom));
			return new PathCard("line_vert_" + randomID(), graph);
		}
		
		private PathCard createCard(Map<CardAnchor, Set<CardAnchor>> adjacency) {
			Graph<CardAnchor> graph = new SolutionGraph<>();
			Map<CardAnchor, Set<CardAnchor>> G = (Map<CardAnchor, Set<CardAnchor>>) getAttribute(graph, "G");
			for (CardAnchor anchor : adjacency.keySet())
				G.put(anchor, adjacency.get(anchor));
			return new PathCard("card_" + randomID(), graph);
		}
		
		private PathCard createStart(Map<CardAnchor, Set<CardAnchor>> adjacency) {
			Graph<CardAnchor> graph = new SolutionGraph<>();
			Map<CardAnchor, Set<CardAnchor>> G = (Map<CardAnchor, Set<CardAnchor>>) getAttribute(graph, "G");
			for (CardAnchor anchor : adjacency.keySet())
				G.put(anchor, adjacency.get(anchor));
			return new StartCard(graph);
		}
		
		private Set<Edge<BoardAnchor>> createEdges(int x1, int y1, CardAnchor anchor1, int x2, int y2, CardAnchor anchor2) {
			BoardAnchor ca1 = BoardAnchor.of(x1, y1, anchor1);
			BoardAnchor ca2 = BoardAnchor.of(x2, y2, anchor2);
			return newSet(Edge.of(ca1, ca2), Edge.of(ca2, ca1));
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		@Nested
		@DisplayName("Aufgabe 4.1.4")
		public class A14 {
			
			public A14() {}
			
			/**
			 * {@link fop.model.board.Gameboard#placeCard(int, int, PathCard)}
			 */
			@Test
			@DisplayName("board")
			public void m1() {
				Gameboard gameboard = new Gameboard();
				Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
				
				// keine Nachbarn
				PathCard plus = createPlus();
				gameboard.placeCard(2, 4, plus);
				assertEquals(1, board.size(), "Die Karte wird nicht hinzugefügt");
				assertEquals(newSet(Position.of(2, 4)), board.keySet(), "Die Karte wird an der falschen Position eingefügt");
				assertEquals(plus, board.get(Position.of(2, 4)), "Es wird nicht die korrekte Karte eingefügt");
				
				// ein Nachbar
				PathCard lineHoriz = createLineHoriz();
				gameboard.placeCard(3, 4, lineHoriz);
				assertEquals(2, board.size(), "Die Karte wird nicht hinzugefügt");
				assertEquals(newSet(Position.of(2, 4), Position.of(3, 4)), board.keySet(), "Die Karte wird an der falschen Position eingefügt");
				assertEquals(plus, board.get(Position.of(2, 4)), "Es werden bereits vorhandene Karten verändert");
				assertEquals(lineHoriz, board.get(Position.of(3, 4)), "Es wird nicht die korrekte Karte eingefügt");
			}
			
			/**
			 * {@link fop.model.board.Gameboard#placeCard(int, int, PathCard)}
			 */
			@Test
			@DisplayName("Knoten")
			public void m2() {
				Gameboard gameboard = new Gameboard();
				Graph<BoardAnchor> graph = new SolutionGraph<>();
				setAttribute(gameboard, "graph", graph);
				
				// kein Nachbar, Kanten und Knoten
				PathCard plus = createPlus();
				gameboard.placeCard(-3, 4, plus);
				Set<BoardAnchor> vertices = newSet();
				vertices.add(BoardAnchor.of(-3, 4, left));
				vertices.add(BoardAnchor.of(-3, 4, bottom));
				vertices.add(BoardAnchor.of(-3, 4, right));
				vertices.add(BoardAnchor.of(-3, 4, top));
				assertEquals(4, graph.vertices().size(), "Es werden nicht alle Knoten hinzugefügt");
				assertEquals(vertices, graph.vertices(), "Die Knoten werden nicht korrekt hinzugefügt");
				
				// keine Kanten, trotzdem Knoten
				PathCard deadPlus = createDeadPlus();
				gameboard.placeCard(-4, 4, deadPlus);
				vertices.add(BoardAnchor.of(-4, 4, left));
				vertices.add(BoardAnchor.of(-4, 4, bottom));
				vertices.add(BoardAnchor.of(-4, 4, right));
				vertices.add(BoardAnchor.of(-4, 4, top));
				assertEquals(8, graph.vertices().size(), "Es werden nicht alle Knoten hinzugefügt, wenn die Karte keine Kanten hat");
				assertEquals(vertices, graph.vertices(), "Die Knoten werden nicht korrekt hinzugefügt");
				
				// ein Nachbar
				PathCard lineVert = createLineVert();
				gameboard.placeCard(-3, 3, lineVert);
				vertices.add(BoardAnchor.of(-3, 3, bottom));
				vertices.add(BoardAnchor.of(-3, 3, top));
				assertEquals(10, graph.vertices().size(), "Es werden nicht alle Knoten hinzugefügt");
				assertEquals(vertices, graph.vertices(), "Die Knoten werden nicht korrekt hinzugefügt");
			}
			
			/**
			 * {@link fop.model.board.Gameboard#placeCard(int, int, PathCard)}
			 */
			@Test
			@DisplayName("Kanten")
			public void m3() {
				Gameboard gameboard = new Gameboard();
				Graph<BoardAnchor> graph = new SolutionGraph<>();
				setAttribute(gameboard, "graph", graph);
				
				// Kanten, keine Nachbarn
				PathCard plus = createPlus();
				gameboard.placeCard(1, 2, plus);
				Set<Edge<BoardAnchor>> edges = newSet();
				edges.addAll(createEdges(1, 2, left, 1, 2, bottom));
				edges.addAll(createEdges(1, 2, left, 1, 2, right));
				edges.addAll(createEdges(1, 2, left, 1, 2, top));
				edges.addAll(createEdges(1, 2, bottom, 1, 2, right));
				edges.addAll(createEdges(1, 2, bottom, 1, 2, top));
				edges.addAll(createEdges(1, 2, right, 1, 2, top));
				assertEquals(6 * 2, graph.edges().size(), "Es werden nicht alle Kanten hinzugefügt");
				assertEquals(edges, graph.edges(), "Die Kanten werden nicht korrekt hinzugefügt");
				
				// keine Kanten, keine Nachbarn
				PathCard deadPlus = createDeadPlus();
				gameboard.placeCard(77, 2, deadPlus);
				assertEquals(6 * 2, graph.edges().size(), "Es werden Kanten hinzugefügt, obwohl die Karte keine Kanten und keine Nachbarn hat");
				assertEquals(edges, graph.edges(), "Es werden Kanten hinzugefügt, obwohl die Karte keine Kanten und keine Nachbarn hat");
				
				// Filter Kanten nur innerhalb derselben Karte
				Function<Set<Edge<BoardAnchor>>, Set<Edge<BoardAnchor>>> filter = e -> e.stream()
						.filter(edge -> edge.x().x() == edge.y().x() && edge.x().y() == edge.y().y()).collect(Collectors.toSet());
				
				// ein Nachbar
				PathCard lineHoriz = createLineHoriz();
				gameboard.placeCard(0, 2, lineHoriz);
				edges.addAll(createEdges(0, 2, left, 0, 2, right));
				assertEquals(7 * 2, filter.apply(graph.edges()).size(), "Es werden nicht alle Kanten hinzugefügt");
				assertEquals(edges, filter.apply(graph.edges()), "Die Kanten werden nicht korrekt hinzugefügt");
			}
			
			/**
			 * {@link fop.model.board.Gameboard#placeCard(int, int, PathCard)}
			 */
			@Test
			@DisplayName("[*] CardAnchor Methoden")
			public void m4() {
				List<String> msg = new ArrayList<>();
				msg.add("!! In den Code schauen !!");
				msg.add("!! In den Code schauen !!");
				msg.add("");
				msg.add("Es MÜSSEN vorkommen:");
				msg.add(" * vertex.getAdjacentPosition(Position.of(x, y))");
				msg.add(" * vertex.getOppositeAnchor()");
				msg.add("");
				msg.add("Es DARF NICHT vorkommen:");
				msg.add(" * CardAnchor.left");
				msg.add(" * CardAnchor.bottom");
				msg.add(" * u.Ä.");
				msg.add("");
				msg.add("Wenn das OK ist, wird der Punkt vergeben.");
				msg.add("");
				fail(msg.stream().collect(Collectors.joining("\n")));
			}
			
			/**
			 * {@link fop.model.board.Gameboard#placeCard(int, int, PathCard)}
			 */
			@Test
			@DisplayName("Kanten zu Nachbarn")
			public void m5() {
				//@formatter:off
				/*
				 * B -- A
				 * |    |
				 * C -- F -- D
				 *      |
				 *      E
				 * F=(-3,-2)
				 */
				//@formatter:on
				
				Gameboard gameboard = new Gameboard();
				Graph<BoardAnchor> graph = new SolutionGraph<>();
				setAttribute(gameboard, "graph", graph);
				
				// Filter Kanten zwischen unterschiedlichen Knoten
				Function<Set<Edge<BoardAnchor>>, Set<Edge<BoardAnchor>>> filter = e -> e.stream()
						.filter(edge -> edge.x().x() != edge.y().x() || edge.x().y() != edge.y().y()).collect(Collectors.toSet());
				
				// A: keine Nachbarn
				PathCard plus = createPlus();
				gameboard.placeCard(-3, -3, plus);
				Set<Edge<BoardAnchor>> edges = newSet();
				assertEquals(0, filter.apply(graph.edges()).size(), "Es werden nicht alle Kanten hinzugefügt");
				assertEquals(edges, filter.apply(graph.edges()), "Die Kanten werden nicht korrekt hinzugefügt");
				
				// B: ein Nachbar
				PathCard deadPlus = createDeadPlus();
				gameboard.placeCard(-4, -3, deadPlus);
				edges.addAll(createEdges(-3, -3, left, -4, -3, right));
				assertEquals(1 * 2, filter.apply(graph.edges()).size(), "Es werden nicht alle Kanten hinzugefügt");
				assertEquals(edges, filter.apply(graph.edges()), "Die Kanten werden nicht korrekt hinzugefügt");
				
				// C: ein Nachbar
				PathCard plus2 = createPlus();
				gameboard.placeCard(-4, -2, plus2);
				edges.addAll(createEdges(-4, -3, bottom, -4, -2, top));
				assertEquals(2 * 2, filter.apply(graph.edges()).size(), "Es werden nicht alle Kanten hinzugefügt");
				assertEquals(edges, filter.apply(graph.edges()), "Die Kanten werden nicht korrekt hinzugefügt");
				
				// D: kein Nachbar
				PathCard lineHoriz = createLineHoriz();
				gameboard.placeCard(-2, -2, lineHoriz);
				assertEquals(2 * 2, filter.apply(graph.edges()).size(),
						"Es werden Kanten zwischen Karten hinzugefüt, obwohl die Karte mit keiner Karte benachbart ist");
				assertEquals(edges, filter.apply(graph.edges()),
						"Es werden Kanten zwischen Karten hinzugefüt, obwohl die Karte mit keiner Karte benachbart ist");
				
				// E: kein Nachbar
				PathCard lineVert = createLineVert();
				gameboard.placeCard(-3, -1, lineVert);
				assertEquals(2 * 2, filter.apply(graph.edges()).size(),
						"Es werden Kanten zwischen Karten hinzugefüt, obwohl die Karte mit keiner Karte benachbart ist");
				assertEquals(edges, filter.apply(graph.edges()),
						"Es werden Kanten zwischen Karten hinzugefüt, obwohl die Karte mit keiner Karte benachbart ist");
				
				// F: vier Nachbarn
				PathCard plus3 = createPlus();
				gameboard.placeCard(-3, -2, plus3);
				edges.addAll(createEdges(-3, -3, bottom, -3, -2, top));
				edges.addAll(createEdges(-4, -2, right, -3, -2, left));
				edges.addAll(createEdges(-2, -2, left, -3, -2, right));
				edges.addAll(createEdges(-3, -1, top, -3, -2, bottom));
				assertEquals(6 * 2, filter.apply(graph.edges()).size(),
						"Es werden nicht alle Kanten hinzugefüt, wenn die Karte mit mehreren Karten benachbart ist");
				assertEquals(edges, filter.apply(graph.edges()),
						"Es werden nicht alle Kanten hinzugefüt, wenn die Karte mit mehreren Karten benachbart ist");
			}
			
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		@Nested
		@DisplayName("Aufgabe 4.1.5")
		public class A15 {
			
			public A15() {}
			
			/**
			 * {@link fop.model.board.Gameboard#removeCard(int, int)}
			 */
			@Test
			@DisplayName("[*] removeCard")
			public void m1() {
				//@formatter:off
				/*
				 * A
				 * 
				 * B -- C
				 */
				//@formatter:on
				
				Gameboard gameboard = new Gameboard();
				Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
				Graph<BoardAnchor> graph = new SolutionGraph<>();
				setAttribute(gameboard, "graph", graph);
				Map<BoardAnchor, Set<BoardAnchor>> G = (Map<BoardAnchor, Set<BoardAnchor>>) getAttribute(graph, "G");
				
				// Karten
				PathCard A = createDeadPlus();
				PathCard B = createPlus();
				PathCard C = createLineHoriz();
				// Board
				board.put(Position.of(1, 1), A);
				board.put(Position.of(4, 6), B);
				board.put(Position.of(5, 6), C);
				// Graph der Karten
				G.put(BoardAnchor.of(1, 1, left), newSet());
				G.put(BoardAnchor.of(1, 1, bottom), newSet());
				G.put(BoardAnchor.of(1, 1, right), newSet());
				G.put(BoardAnchor.of(1, 1, top), newSet());
				G.put(BoardAnchor.of(4, 6, left), newSet(BoardAnchor.of(4, 6, bottom), BoardAnchor.of(4, 6, right), BoardAnchor.of(4, 6, top)));
				G.put(BoardAnchor.of(4, 6, bottom), newSet(BoardAnchor.of(4, 6, left), BoardAnchor.of(4, 6, right), BoardAnchor.of(4, 6, top)));
				G.put(BoardAnchor.of(4, 6, right), newSet(BoardAnchor.of(4, 6, left), BoardAnchor.of(4, 6, bottom), BoardAnchor.of(4, 6, top)));
				G.put(BoardAnchor.of(4, 6, top), newSet(BoardAnchor.of(4, 6, left), BoardAnchor.of(4, 6, bottom), BoardAnchor.of(4, 6, right)));
				G.put(BoardAnchor.of(5, 6, left), newSet(BoardAnchor.of(5, 6, right)));
				G.put(BoardAnchor.of(5, 6, right), newSet(BoardAnchor.of(5, 6, left)));
				// Graph zwischen Karten
				G.get(BoardAnchor.of(4, 6, right)).add(BoardAnchor.of(5, 6, left));
				G.get(BoardAnchor.of(5, 6, left)).add(BoardAnchor.of(4, 6, right));
				// Variablen
				Set<BoardAnchor> vertices = graph.vertices();
				Set<Edge<BoardAnchor>> edges = graph.edges();
				
				// keine Kanten, keine Nachbarn
				PathCard ret = gameboard.removeCard(1, 1);
				vertices.remove(BoardAnchor.of(1, 1, left));
				vertices.remove(BoardAnchor.of(1, 1, bottom));
				vertices.remove(BoardAnchor.of(1, 1, right));
				vertices.remove(BoardAnchor.of(1, 1, top));
				assertEquals(newSet(Position.of(4, 6), Position.of(5, 6)), board.keySet(), "Die Karte wird nicht korret aus board entfernt");
				assertEquals(vertices, graph.vertices(), "Die Knoten werden nicht korrekt entfernt");
				assertEquals(edges, graph.edges(), "Die Kanten werden verändert, obwohl keine Kanten entfernt werden sollen");
				assertEquals(A, ret, "Der Rückgabewert ist falsch");
				
				// Knoten und Kanten, ein Nachbar
				ret = gameboard.removeCard(4, 6);
				vertices.remove(BoardAnchor.of(4, 6, left));
				vertices.remove(BoardAnchor.of(4, 6, bottom));
				vertices.remove(BoardAnchor.of(4, 6, right));
				vertices.remove(BoardAnchor.of(4, 6, top));
				edges.removeAll(createEdges(4, 6, left, 4, 6, bottom));
				edges.removeAll(createEdges(4, 6, left, 4, 6, right));
				edges.removeAll(createEdges(4, 6, left, 4, 6, top));
				edges.removeAll(createEdges(4, 6, bottom, 4, 6, right));
				edges.removeAll(createEdges(4, 6, bottom, 4, 6, top));
				edges.removeAll(createEdges(4, 6, right, 4, 6, top));
				edges.removeAll(createEdges(4, 6, right, 5, 6, left));
				assertEquals(newSet(Position.of(5, 6)), board.keySet(), "Die Karte wird nicht korret aus board entfernt");
				assertEquals(vertices, graph.vertices(), "Die Knoten werden nicht korrekt entfernt");
				assertEquals(edges, graph.edges(), "Die Kanten werden nicht korrekt entfernt");
				assertEquals(B, ret, "Der Rückgabewert ist falsch");
				
				// komplett leer machen
				ret = gameboard.removeCard(5, 6);
				assertEquals(newSet(), board.keySet(), "Die Karte wird nicht korret aus board entfernt");
				assertEquals(newSet(), graph.vertices(), "Die Knoten werden nicht korrekt entfernt");
				assertEquals(newSet(), graph.edges(), "Die Kanten werden nicht korrekt entfernt");
				assertEquals(C, ret, "Der Rückgabewert ist falsch");
				
				// wird nur angezeigt, wenn sonst alles korrekt ist
				List<String> msg = new ArrayList<>();
				msg.add("!! In den Code schauen !!");
				msg.add("!! In den Code schauen !!");
				msg.add("");
				msg.add("Es DARF NICHT vorkommen:");
				msg.add(" * CardAnchor.left");
				msg.add(" * CardAnchor.bottom");
				msg.add(" * u.Ä.");
				msg.add("");
				msg.add("Wenn das OK ist, wird der Punkt vergeben.");
				msg.add("Die restlichen Tests waren erfolgreich.");
				msg.add("");
				fail(msg.stream().collect(Collectors.joining("\n")));
			}
			
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		@Nested
		@DisplayName("Aufgabe 4.1.6")
		public class A16 {
			
			public A16() {}
			
			/**
			 * {@link fop.model.board.Gameboard#isPositionEmpty(int, int)}
			 */
			@Test
			@DisplayName("isPositionEmpty")
			public void m1() throws Exception {
				//@formatter:off
				/*
				 * A
				 * 
				 * B -- C
				 */
				//@formatter:on
				
				Gameboard gameboard = new Gameboard();
				Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
				Graph<BoardAnchor> graph = new SolutionGraph<>();
				setAttribute(gameboard, "graph", graph);
				Map<BoardAnchor, Set<BoardAnchor>> G = (Map<BoardAnchor, Set<BoardAnchor>>) getAttribute(graph, "G");
				
				// Karten
				PathCard A = createDeadPlus();
				PathCard B = createPlus();
				PathCard C = createLineHoriz();
				// Board
				board.put(Position.of(1, 1), A);
				board.put(Position.of(4, 6), B);
				board.put(Position.of(5, 6), C);
				// Graph der Karten
				G.put(BoardAnchor.of(1, 1, left), newSet());
				G.put(BoardAnchor.of(1, 1, bottom), newSet());
				G.put(BoardAnchor.of(1, 1, right), newSet());
				G.put(BoardAnchor.of(1, 1, top), newSet());
				G.put(BoardAnchor.of(4, 6, left), newSet(BoardAnchor.of(4, 6, bottom), BoardAnchor.of(4, 6, right), BoardAnchor.of(4, 6, top)));
				G.put(BoardAnchor.of(4, 6, bottom), newSet(BoardAnchor.of(4, 6, left), BoardAnchor.of(4, 6, right), BoardAnchor.of(4, 6, top)));
				G.put(BoardAnchor.of(4, 6, right), newSet(BoardAnchor.of(4, 6, left), BoardAnchor.of(4, 6, bottom), BoardAnchor.of(4, 6, top)));
				G.put(BoardAnchor.of(4, 6, top), newSet(BoardAnchor.of(4, 6, left), BoardAnchor.of(4, 6, bottom), BoardAnchor.of(4, 6, right)));
				G.put(BoardAnchor.of(5, 6, left), newSet(BoardAnchor.of(5, 6, right)));
				G.put(BoardAnchor.of(5, 6, right), newSet(BoardAnchor.of(5, 6, left)));
				// Graph zwischen Karten
				G.get(BoardAnchor.of(4, 6, right)).add(BoardAnchor.of(5, 6, left));
				G.get(BoardAnchor.of(5, 6, left)).add(BoardAnchor.of(4, 6, right));
				
				// Test true
				assertTrue((boolean) callMethod(gameboard, "isPositionEmpty", 0, 0), "Für freie Positionen wird false zurückgegeben");
				assertTrue((boolean) callMethod(gameboard, "isPositionEmpty", 4, 0), "Für freie Positionen wird false zurückgegeben");
				assertTrue((boolean) callMethod(gameboard, "isPositionEmpty", -5, 0), "Für freie Positionen wird false zurückgegeben");
				assertTrue((boolean) callMethod(gameboard, "isPositionEmpty", 0, 3), "Für freie Positionen wird false zurückgegeben");
				assertTrue((boolean) callMethod(gameboard, "isPositionEmpty", 1, 2), "Für freie Positionen wird false zurückgegeben");
				assertTrue((boolean) callMethod(gameboard, "isPositionEmpty", 6, 4), "Für freie Positionen wird false zurückgegeben");
				
				// Test false
				assertFalse((boolean) callMethod(gameboard, "isPositionEmpty", 1, 1), "Für belegte Positionen wird true zurückgegeben");
				assertFalse((boolean) callMethod(gameboard, "isPositionEmpty", 4, 6), "Für belegte Positionen wird true zurückgegeben");
				assertFalse((boolean) callMethod(gameboard, "isPositionEmpty", 5, 6), "Für belegte Positionen wird true zurückgegeben");
			}
			
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		private Gameboard createLargeTestGameboard() {
			//@formatter:off
			/*
			 * ═ ist Weg
			 * ─ ist Sackgasse
			 * 
			 *       ╠     ╬
			 * 
			 * ╤  S  ╬  ╦  ╧  ╬
			 * 
			 *          ╝
			 *    ╦
			 */
			//@formatter:on
			
			Gameboard gameboard = new Gameboard();
			Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
			Graph<BoardAnchor> graph = new SolutionGraph<>();
			setAttribute(gameboard, "graph", graph);
			Map<BoardAnchor, Set<BoardAnchor>> G = (Map<BoardAnchor, Set<BoardAnchor>>) getAttribute(graph, "G");
			
			// Karten
			PathCard cS = createStart();
			PathCard cA = createCard(Map.of(bottom, newSet(right, top), right, newSet(bottom, top), top, newSet(bottom, right)));
			PathCard cB = createPlus();
			PathCard cC = createCard(Map.of(left, newSet(right), right, newSet(left), bottom, newSet()));
			PathCard cD = createPlus();
			PathCard cE = createCard(Map.of(left, newSet(bottom, right), bottom, newSet(left, right), right, newSet(left, bottom)));
			PathCard cF = createCard(Map.of(left, newSet(right), right, newSet(left), top, newSet()));
			PathCard cG = createPlus();
			PathCard cH = createCard(Map.of(left, newSet(top), top, newSet(left)));
			PathCard cI = createCard(Map.of(left, newSet(bottom, right), bottom, newSet(left, right), right, newSet(left, bottom)));
			// Board
			board.put(Position.of(0, 0), cS);
			board.put(Position.of(1, -1), cA);
			board.put(Position.of(3, -1), cB);
			board.put(Position.of(-1, 0), cC);
			board.put(Position.of(1, 0), cD);
			board.put(Position.of(2, 0), cE);
			board.put(Position.of(3, 0), cF);
			board.put(Position.of(4, 0), cG);
			board.put(Position.of(2, 1), cH);
			board.put(Position.of(0, 2), cI);
			// Graph der Karten
			G.put(BoardAnchor.of(0, 0, left), newSet(BoardAnchor.of(0, 0, bottom), BoardAnchor.of(0, 0, right), BoardAnchor.of(0, 0, top)));
			G.put(BoardAnchor.of(0, 0, bottom), newSet(BoardAnchor.of(0, 0, left), BoardAnchor.of(0, 0, right), BoardAnchor.of(0, 0, top)));
			G.put(BoardAnchor.of(0, 0, right), newSet(BoardAnchor.of(0, 0, left), BoardAnchor.of(0, 0, bottom), BoardAnchor.of(0, 0, top)));
			G.put(BoardAnchor.of(0, 0, top), newSet(BoardAnchor.of(0, 0, left), BoardAnchor.of(0, 0, bottom), BoardAnchor.of(0, 0, right)));
			G.put(BoardAnchor.of(1, -1, bottom), newSet(BoardAnchor.of(1, -1, right), BoardAnchor.of(1, -1, top)));
			G.put(BoardAnchor.of(1, -1, right), newSet(BoardAnchor.of(1, -1, bottom), BoardAnchor.of(1, -1, top)));
			G.put(BoardAnchor.of(1, -1, top), newSet(BoardAnchor.of(1, -1, bottom), BoardAnchor.of(1, -1, right)));
			G.put(BoardAnchor.of(3, -1, left), newSet(BoardAnchor.of(3, -1, bottom), BoardAnchor.of(3, -1, right), BoardAnchor.of(3, -1, top)));
			G.put(BoardAnchor.of(3, -1, bottom), newSet(BoardAnchor.of(3, -1, left), BoardAnchor.of(3, -1, right), BoardAnchor.of(3, -1, top)));
			G.put(BoardAnchor.of(3, -1, right), newSet(BoardAnchor.of(3, -1, left), BoardAnchor.of(3, -1, bottom), BoardAnchor.of(3, -1, top)));
			G.put(BoardAnchor.of(3, -1, top), newSet(BoardAnchor.of(3, -1, left), BoardAnchor.of(3, -1, bottom), BoardAnchor.of(3, -1, right)));
			G.put(BoardAnchor.of(-1, 0, left), newSet(BoardAnchor.of(-1, 0, right)));
			G.put(BoardAnchor.of(-1, 0, right), newSet(BoardAnchor.of(-1, 0, left)));
			G.put(BoardAnchor.of(-1, 0, bottom), newSet());
			G.put(BoardAnchor.of(1, 0, left), newSet(BoardAnchor.of(1, 0, bottom), BoardAnchor.of(1, 0, right), BoardAnchor.of(1, 0, top)));
			G.put(BoardAnchor.of(1, 0, bottom), newSet(BoardAnchor.of(1, 0, left), BoardAnchor.of(1, 0, right), BoardAnchor.of(1, 0, top)));
			G.put(BoardAnchor.of(1, 0, right), newSet(BoardAnchor.of(1, 0, left), BoardAnchor.of(1, 0, bottom), BoardAnchor.of(1, 0, top)));
			G.put(BoardAnchor.of(1, 0, top), newSet(BoardAnchor.of(1, 0, left), BoardAnchor.of(1, 0, bottom), BoardAnchor.of(1, 0, right)));
			G.put(BoardAnchor.of(2, 0, left), newSet(BoardAnchor.of(2, 0, bottom), BoardAnchor.of(2, 0, right)));
			G.put(BoardAnchor.of(2, 0, right), newSet(BoardAnchor.of(2, 0, left), BoardAnchor.of(2, 0, bottom)));
			G.put(BoardAnchor.of(2, 0, bottom), newSet(BoardAnchor.of(2, 0, left), BoardAnchor.of(2, 0, right)));
			G.put(BoardAnchor.of(3, 0, left), newSet(BoardAnchor.of(3, 0, right)));
			G.put(BoardAnchor.of(3, 0, right), newSet(BoardAnchor.of(3, 0, left)));
			G.put(BoardAnchor.of(3, 0, top), newSet());
			G.put(BoardAnchor.of(4, 0, left), newSet(BoardAnchor.of(4, 0, bottom), BoardAnchor.of(4, 0, right), BoardAnchor.of(4, 0, top)));
			G.put(BoardAnchor.of(4, 0, bottom), newSet(BoardAnchor.of(4, 0, left), BoardAnchor.of(4, 0, right), BoardAnchor.of(4, 0, top)));
			G.put(BoardAnchor.of(4, 0, right), newSet(BoardAnchor.of(4, 0, left), BoardAnchor.of(4, 0, bottom), BoardAnchor.of(4, 0, top)));
			G.put(BoardAnchor.of(4, 0, top), newSet(BoardAnchor.of(4, 0, left), BoardAnchor.of(4, 0, bottom), BoardAnchor.of(4, 0, right)));
			G.put(BoardAnchor.of(2, 1, left), newSet(BoardAnchor.of(2, 1, top)));
			G.put(BoardAnchor.of(2, 1, top), newSet(BoardAnchor.of(2, 1, left)));
			G.put(BoardAnchor.of(0, 2, left), newSet(BoardAnchor.of(0, 2, bottom), BoardAnchor.of(0, 2, right)));
			G.put(BoardAnchor.of(0, 2, right), newSet(BoardAnchor.of(0, 2, left), BoardAnchor.of(0, 2, bottom)));
			G.put(BoardAnchor.of(0, 2, bottom), newSet(BoardAnchor.of(0, 2, left), BoardAnchor.of(0, 2, right)));
			// Graph zwischen Karten
			G.get(BoardAnchor.of(1, -1, bottom)).add(BoardAnchor.of(1, 0, top));
			G.get(BoardAnchor.of(1, 0, top)).add(BoardAnchor.of(1, -1, bottom));
			G.get(BoardAnchor.of(3, -1, bottom)).add(BoardAnchor.of(3, 0, top));
			G.get(BoardAnchor.of(3, 0, top)).add(BoardAnchor.of(3, -1, bottom));
			G.get(BoardAnchor.of(-1, 0, right)).add(BoardAnchor.of(0, 0, left));
			G.get(BoardAnchor.of(0, 0, left)).add(BoardAnchor.of(-1, 0, right));
			G.get(BoardAnchor.of(0, 0, right)).add(BoardAnchor.of(1, 0, left));
			G.get(BoardAnchor.of(1, 0, left)).add(BoardAnchor.of(0, 0, right));
			G.get(BoardAnchor.of(1, 0, right)).add(BoardAnchor.of(2, 0, left));
			G.get(BoardAnchor.of(2, 0, left)).add(BoardAnchor.of(1, 0, right));
			G.get(BoardAnchor.of(2, 0, right)).add(BoardAnchor.of(3, 0, left));
			G.get(BoardAnchor.of(3, 0, left)).add(BoardAnchor.of(2, 0, right));
			G.get(BoardAnchor.of(3, 0, right)).add(BoardAnchor.of(4, 0, left));
			G.get(BoardAnchor.of(4, 0, left)).add(BoardAnchor.of(3, 0, right));
			G.get(BoardAnchor.of(2, 0, bottom)).add(BoardAnchor.of(2, 1, top));
			G.get(BoardAnchor.of(2, 1, top)).add(BoardAnchor.of(2, 0, bottom));
			
			return gameboard;
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		@Nested
		@DisplayName("Aufgabe 4.1.7")
		public class A17 {
			/*
			 * Notiz:
			 * Es werden hier bewusst nur Tests aufgeführt, die Positionen
			 * testen, an denen keine Karte liegt, obwohl das die Methode
			 * 'isPositionEmpty(int x, int y)' prüft.
			 */
			
			public A17() {}
			
			/**
			 * {@link fop.model.board.Gameboard#existsPathFromStartCard(int, int)}
			 */
			@Test
			@DisplayName("[*] Graph.hasPath")
			public void m1() {
				List<String> msg = new ArrayList<>();
				msg.add("!! In den Code schauen !!");
				msg.add("!! In den Code schauen !!");
				msg.add("");
				msg.add("Es MUSS vorkommen:");
				msg.add(" * graph.hasPath(pos1, pos2)");
				msg.add("");
				msg.add("Wenn das OK ist, wird der Punkt vergeben.");
				msg.add("");
				fail(msg.stream().collect(Collectors.joining("\n")));
			}
			
			/**
			 * {@link fop.model.board.Gameboard#existsPathFromStartCard(int, int)}
			 */
			@Test
			@DisplayName("[*] CardAnchor Methoden")
			public void m2() {
				List<String> msg = new ArrayList<>();
				msg.add("!! In den Code schauen !!");
				msg.add("!! In den Code schauen !!");
				msg.add("");
				msg.add("Es MÜSSEN vorkommen:");
				msg.add(" * anchor.getAdjacentPosition(pos)");
				msg.add(" * anchor.getOppositeAnchor()");
				msg.add("");
				msg.add("Es DARF NICHT vorkommen:");
				msg.add(" * CardAnchor.left");
				msg.add(" * CardAnchor.bottom");
				msg.add(" * u.Ä.");
				msg.add("");
				msg.add("Wenn das OK ist, wird der Punkt vergeben.");
				msg.add("");
				fail(msg.stream().collect(Collectors.joining("\n")));
			}
			
			/**
			 * {@link fop.model.board.Gameboard#existsPathFromStartCard(int, int)}
			 */
			@Test
			@DisplayName("alle Zielanker")
			public void m3() throws Exception {
				//@formatter:off
				/*
				 * x    ?    x
				 *      |
				 * ? -- S -- ?
				 *      |
				 * x    ?    x
				 * 
				 * S @ (0, 0)
				 */
				//@formatter:on
				
				Gameboard gameboard = new Gameboard();
				Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
				Graph<BoardAnchor> graph = new SolutionGraph<>();
				setAttribute(gameboard, "graph", graph);
				Map<BoardAnchor, Set<BoardAnchor>> G = (Map<BoardAnchor, Set<BoardAnchor>>) getAttribute(graph, "G");
				
				PathCard S = createStart();
				board.put(Position.of(0, 0), S);
				G.put(BoardAnchor.of(0, 0, left), newSet(BoardAnchor.of(0, 0, bottom), BoardAnchor.of(0, 0, right), BoardAnchor.of(0, 0, top)));
				G.put(BoardAnchor.of(0, 0, bottom), newSet(BoardAnchor.of(0, 0, left), BoardAnchor.of(0, 0, right), BoardAnchor.of(0, 0, top)));
				G.put(BoardAnchor.of(0, 0, right), newSet(BoardAnchor.of(0, 0, left), BoardAnchor.of(0, 0, bottom), BoardAnchor.of(0, 0, top)));
				G.put(BoardAnchor.of(0, 0, top), newSet(BoardAnchor.of(0, 0, left), BoardAnchor.of(0, 0, bottom), BoardAnchor.of(0, 0, right)));
				
				// Test true
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, 0), "Der Ankerpunkt left wird nicht überprüft");
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, -1), "Der Ankerpunkt bottom wird nicht überprüft");
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 0), "Der Ankerpunkt right wird nicht überprüft");
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 1), "Der Ankerpunkt top wird nicht überprüft");
				
				// Test false
				String sFalse = "Es wird ein Weg gefunden, obwohl keiner existiert";
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, -1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, -1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, 0), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, -2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, 0), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 6, -3), sFalse);
			}
			
			/**
			 * {@link fop.model.board.Gameboard#existsPathFromStartCard(int, int)}
			 */
			@Test
			@DisplayName("gut genug")
			public void m4() throws Exception {
				Gameboard gameboard = createLargeTestGameboard();
				
				//@formatter:off
				/*
				 *       ╠     ╬
				 * 
				 * ╤  S  ╬  ╦  ╧  ╬
				 * 
				 *          ╝
				 *    ╦
				 */
				//@formatter:on
				
				// Test true
				String sTrue = "Der Weg wird nicht korrekt gefunden";
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, -2), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, -1), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, -1), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 4, -1), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, 0), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 5, 0), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 1), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, 1), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 4, 1), sTrue);
				
				// Test false
				String sFalse = "Es wird ein Weg gefunden, obwohl keiner existiert";
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -3, -3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, -3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, -3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, -3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, -3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, -3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 3, -3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 4, -3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 5, -3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 6, -3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -3, -2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, -2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, -2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, -2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, -2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 3, -2),
						"Es wird ein Weg gefunden, obwohl der Graph an der Stelle unterbrochen ist");
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 4, -2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 5, -2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 6, -2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -3, -1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, -1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, -1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 5, -1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 6, -1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -3, 0), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 6, 0), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -3, 1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, 1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 1),
						"Es wird ein Weg gefunden, obwohl der Graph an der Stelle unterbrochen ist");
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 3, 1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 5, 1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 6, 1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -3, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 2),
						"Es wird ein Weg gefunden, obwohl der Graph an der Stelle nicht mit der Startkarte verbunden ist");
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, 2),
						"Es wird ein Weg gefunden, obwohl der Graph an der Stelle nicht mit der Startkarte verbunden ist");
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 3, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 4, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 5, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 6, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -3, 3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, 3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 3),
						"Es wird ein Weg gefunden, obwohl der Graph an der Stelle nicht mit der Startkarte verbunden ist");
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, 3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, 3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 3, 3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 4, 3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 5, 3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 6, 3), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -3, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 3, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 4, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 5, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 6, 4), sFalse);
			}
			
			/**
			 * {@link fop.model.board.Gameboard#existsPathFromStartCard(int, int)}
			 */
			@Test
			@DisplayName("alle Startanker")
			public void m5() throws Exception {
				/*
				 * Notiz:
				 * Schlägt fehl, wenn 'alle Zielanker' fehlschlägt.
				 */
				
				//@formatter:off
				/*
				 * x    ?    x
				 *      |
				 * ? -- S -- ?
				 *      |
				 * x    ?    x
				 * 
				 * S = Dead Plus @ (0, 0)
				 */
				//@formatter:on
				
				Gameboard gameboard = new Gameboard();
				Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
				Graph<BoardAnchor> graph = new SolutionGraph<>();
				setAttribute(gameboard, "graph", graph);
				Map<BoardAnchor, Set<BoardAnchor>> G = (Map<BoardAnchor, Set<BoardAnchor>>) getAttribute(graph, "G");
				
				PathCard S = createStart(Map.of(left, newSet(), bottom, newSet(), right, newSet(), top, newSet()));
				board.put(Position.of(0, 0), S);
				G.put(BoardAnchor.of(0, 0, left), newSet());
				G.put(BoardAnchor.of(0, 0, bottom), newSet());
				G.put(BoardAnchor.of(0, 0, right), newSet());
				G.put(BoardAnchor.of(0, 0, top), newSet());
				
				// Test true
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, 0), "Der Ankerpunkt right wird nicht überprüft");
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, -1), "Der Ankerpunkt top wird nicht überprüft");
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 0), "Der Ankerpunkt left wird nicht überprüft");
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 1), "Der Ankerpunkt bottom wird nicht überprüft");
				
				// Test false
				String sFalse = "Es wird ein Weg gefunden, obwohl keiner existiert";
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, -1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, -1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, 0), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, -2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, 0), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 6, -3), sFalse);
			}
			
			/**
			 * {@link fop.model.board.Gameboard#existsPathFromStartCard(int, int)}
			 */
			@Test
			@DisplayName("beliebige Startposition")
			public void m6() throws Exception {
				/*
				 * Notiz:
				 * Schlägt fehl, wenn 'alle Zielanker' oder 'alle Startpositionen' fehlschlägt.
				 */
				
				//@formatter:off
				/*
				 * x    ?    x
				 *      |
				 * ? -- S -- ?
				 *      |
				 * x    ?    x
				 * 
				 * S @ (42, -10)
				 */
				//@formatter:on
				
				Gameboard gameboard = new Gameboard();
				Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
				Graph<BoardAnchor> graph = new SolutionGraph<>();
				setAttribute(gameboard, "graph", graph);
				Map<BoardAnchor, Set<BoardAnchor>> G = (Map<BoardAnchor, Set<BoardAnchor>>) getAttribute(graph, "G");
				
				PathCard S = createStart();
				board.put(Position.of(42, -10), S);
				G.put(BoardAnchor.of(42, -10, left),
						newSet(BoardAnchor.of(42, -10, bottom), BoardAnchor.of(42, -10, right), BoardAnchor.of(42, -10, top)));
				G.put(BoardAnchor.of(42, -10, bottom),
						newSet(BoardAnchor.of(42, -10, left), BoardAnchor.of(42, -10, right), BoardAnchor.of(42, -10, top)));
				G.put(BoardAnchor.of(42, -10, right),
						newSet(BoardAnchor.of(42, -10, left), BoardAnchor.of(42, -10, bottom), BoardAnchor.of(42, -10, top)));
				G.put(BoardAnchor.of(42, -10, top),
						newSet(BoardAnchor.of(42, -10, left), BoardAnchor.of(42, -10, bottom), BoardAnchor.of(42, -10, right)));
				
				// Test true
				String sTrue = "Es werden nicht alle Startpositionen überprüft";
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 43, -10), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 42, -11), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 41, -10), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 42, -9), sTrue);
				
				// Test false
				String sFalse = "Es wird ein Weg gefunden, obwohl keiner existiert";
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 43, -11), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 41, -11), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 41, -9), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 41, -11), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 44, -10), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 42, -12), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 40, -10), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 42, -8), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, 0), sFalse);
			}
			
			/**
			 * {@link fop.model.board.Gameboard#existsPathFromStartCard(int, int)}
			 */
			@Test
			@DisplayName("mehrere Startkarten")
			public void m7() throws Exception {
				/*
				 * Notiz:
				 * Schlägt fehl, wenn 'alle Zielanker' oder 'alle Startpositionen' fehlschlägt.
				 */
				
				//@formatter:off
				/*
				 * Drei Startkarten A, B und C
				 * 
				 * x    ?    x    ?    x
				 *      |         |
				 * ? -- A -- ? -- B -- ?
				 *      |         |
				 * x    ?    x    ?    x
				 * 
				 * x    ?    x
				 *      |
				 * ? -- C -- ?
				 *      |
				 * x    ?    x
				 */
				//@formatter:on
				
				Gameboard gameboard = new Gameboard();
				Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
				Graph<BoardAnchor> graph = new SolutionGraph<>();
				setAttribute(gameboard, "graph", graph);
				Map<BoardAnchor, Set<BoardAnchor>> G = (Map<BoardAnchor, Set<BoardAnchor>>) getAttribute(graph, "G");
				
				PathCard A = createStart();
				PathCard B = createStart();
				PathCard C = createStart();
				board.put(Position.of(-1, 3), A);
				board.put(Position.of(1, 3), B);
				board.put(Position.of(4, 9), C);
				G.put(BoardAnchor.of(-1, 3, left),
						newSet(BoardAnchor.of(-1, 3, bottom), BoardAnchor.of(-1, 3, right), BoardAnchor.of(-1, 3, top)));
				G.put(BoardAnchor.of(-1, 3, bottom),
						newSet(BoardAnchor.of(-1, 3, left), BoardAnchor.of(-1, 3, right), BoardAnchor.of(-1, 3, top)));
				G.put(BoardAnchor.of(-1, 3, right),
						newSet(BoardAnchor.of(-1, 3, left), BoardAnchor.of(-1, 3, bottom), BoardAnchor.of(-1, 3, top)));
				G.put(BoardAnchor.of(-1, 3, top),
						newSet(BoardAnchor.of(-1, 3, left), BoardAnchor.of(-1, 3, bottom), BoardAnchor.of(-1, 3, right)));
				G.put(BoardAnchor.of(1, 3, left), newSet(BoardAnchor.of(1, 3, bottom), BoardAnchor.of(1, 3, right), BoardAnchor.of(1, 3, top)));
				G.put(BoardAnchor.of(1, 3, bottom), newSet(BoardAnchor.of(1, 3, left), BoardAnchor.of(1, 3, right), BoardAnchor.of(1, 3, top)));
				G.put(BoardAnchor.of(1, 3, right), newSet(BoardAnchor.of(1, 3, left), BoardAnchor.of(1, 3, bottom), BoardAnchor.of(1, 3, top)));
				G.put(BoardAnchor.of(1, 3, top), newSet(BoardAnchor.of(1, 3, left), BoardAnchor.of(1, 3, bottom), BoardAnchor.of(1, 3, right)));
				G.put(BoardAnchor.of(4, 9, left), newSet(BoardAnchor.of(4, 9, bottom), BoardAnchor.of(4, 9, right), BoardAnchor.of(4, 9, top)));
				G.put(BoardAnchor.of(4, 9, bottom), newSet(BoardAnchor.of(4, 9, left), BoardAnchor.of(4, 9, right), BoardAnchor.of(4, 9, top)));
				G.put(BoardAnchor.of(4, 9, right), newSet(BoardAnchor.of(4, 9, left), BoardAnchor.of(4, 9, bottom), BoardAnchor.of(4, 9, top)));
				G.put(BoardAnchor.of(4, 9, top), newSet(BoardAnchor.of(4, 9, left), BoardAnchor.of(4, 9, bottom), BoardAnchor.of(4, 9, right)));
				
				// Test true
				String sTrue = "Es werden nicht alle Startkarten überprüft";
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, 3), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 2), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 3),
						"Der Weg wird nicht gefunden, wenn es zwei passende Startkarten gibt");
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 4), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, 2), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, 3), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, 4), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 3, 9), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 4, 8), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 5, 9), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 4, 10), sTrue);
				
				// Test false
				String sFalse = "Es wird ein Weg gefunden, obwohl keiner existiert";
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, 4), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 3, 8), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 5, 8), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 3, 10), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 5, 10), sFalse);
			}
			
			/**
			 * {@link fop.model.board.Gameboard#existsPathFromStartCard(int, int)}
			 */
			@Test
			@DisplayName("beliebiger Startgraph")
			public void m8() throws Exception {
				//@formatter:off
				/*
				 * x    ?    x
				 *      |
				 * x -- S    ?
				 * 
				 * x    x    x
				 * 
				 * S = Curve Up @ (0, 0)
				 */
				//@formatter:on
				
				Gameboard gameboard = new Gameboard();
				Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
				Graph<BoardAnchor> graph = new SolutionGraph<>();
				setAttribute(gameboard, "graph", graph);
				Map<BoardAnchor, Set<BoardAnchor>> G = (Map<BoardAnchor, Set<BoardAnchor>>) getAttribute(graph, "G");
				
				PathCard S = createStart(Map.of(left, newSet(top), top, newSet(left)));
				board.put(Position.of(0, 0), S);
				G.put(BoardAnchor.of(0, 0, left), newSet(BoardAnchor.of(0, 0, top)));
				G.put(BoardAnchor.of(0, 0, top), newSet(BoardAnchor.of(0, 0, left)));
				
				// Test true
				String sTrue = "Der Weg wird nicht korrekt gefunden";
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, -1), sTrue);
				assertTrue((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 0), sTrue);
				
				// Test anderer Graph
				String sGraph = "Es wird ein Weg gefunden, obwohl die Startkarte keinen Ankerpunkt an dieser Seite hat";
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, 0), sGraph);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 1), sGraph);
				
				// Test false
				String sFalse = "Es wird ein Weg gefunden, obwohl keiner existiert";
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 1, -1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, -1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -1, 1), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 2, 0), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, -2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", -2, 0), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 0, 2), sFalse);
				assertFalse((boolean) callMethod(gameboard, "existsPathFromStartCard", 6, -3), sFalse);
			}
			
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		@Nested
		@DisplayName("Aufgabe 4.1.8")
		public class A18 {
			/*
			 * Notiz:
			 * Es werden hier bewusst nur Tests aufgeführt, die Positionen
			 * testen, an denen keine Karte liegt, obwohl das die Methode
			 * 'isPositionEmpty(int x, int y)' prüft.
			 */
			
			public A18() {}
			
			/**
			 * {@link fop.model.board.Gameboard#doesCardMatchItsNeighbors(int, int, PathCard)}
			 */
			@Test
			@DisplayName("[*] CardAnchor Methoden")
			public void m1() {
				List<String> msg = new ArrayList<>();
				msg.add("!! In den Code schauen !!");
				msg.add("!! In den Code schauen !!");
				msg.add("");
				msg.add("Es MÜSSEN vorkommen:");
				msg.add(" * anchor.getAdjacentPosition(pos)");
				msg.add(" * anchor.getOppositeAnchor()");
				msg.add("");
				msg.add("Es DARF NICHT vorkommen:");
				msg.add(" * CardAnchor.left");
				msg.add(" * CardAnchor.bottom");
				msg.add(" * u.Ä.");
				msg.add(" * Position.of(x+1, y)");
				msg.add(" * Position.of(x, y+1)");
				msg.add(" * u.Ä.");
				msg.add("");
				msg.add("Wenn das OK ist, wird der Punkt vergeben.");
				msg.add("");
				fail(msg.stream().collect(Collectors.joining("\n")));
			}
			
			/**
			 * {@link fop.model.board.Gameboard#doesCardMatchItsNeighbors(int, int, PathCard)}
			 */
			@Test
			@DisplayName("(*) leere Position")
			public void m2() throws Exception {
				//@formatter:off
				/*
				 *   ?
				 */
				//@formatter:on
				
				Gameboard gameboard = new Gameboard();
				Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
				Graph<BoardAnchor> graph = new SolutionGraph<>();
				setAttribute(gameboard, "graph", graph);
				Map<BoardAnchor, Set<BoardAnchor>> G = (Map<BoardAnchor, Set<BoardAnchor>>) getAttribute(graph, "G");
				
				String sEmpty = "Es wird false zurückgegeben, obwohl das Wegelabyrinth leer ist";
				// Test ═
				PathCard lineHoriz = createLineHoriz();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, lineHoriz), sEmpty);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 7, lineHoriz), sEmpty);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 0, lineHoriz), sEmpty);
				// Test ║
				PathCard lineVert = createLineVert();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, lineVert), sEmpty);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 8, 4, lineVert), sEmpty);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 0, lineVert), sEmpty);
				// Test ╬
				PathCard plus = createPlus();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, plus), sEmpty);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -7, 2, plus), sEmpty);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 0, plus), sEmpty);
				// Test ┼
				PathCard deadPlus = createDeadPlus();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, deadPlus), sEmpty);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -7, -9, deadPlus), sEmpty);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 0, deadPlus), sEmpty);
				// Test Start
				PathCard start = createStart();
				String sStartEmpty = "Für das Überprüfen einer Startkarte wird false zurückgegeben, obwohl das Wegelabyrinth leer ist";
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, start), sStartEmpty);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -7, -9, start), sStartEmpty);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 0, start), sStartEmpty);
				
				
				//@formatter:off
				/*
				 *   ╬
				 * -----
				 *   ?
				 */
				//@formatter:on
				
				PathCard A = createPlus();
				board.put(Position.of(80, -10), A);
				G.put(BoardAnchor.of(80, -10, left),
						newSet(BoardAnchor.of(80, -10, bottom), BoardAnchor.of(80, -10, right), BoardAnchor.of(80, -10, top)));
				G.put(BoardAnchor.of(80, -10, bottom),
						newSet(BoardAnchor.of(80, -10, left), BoardAnchor.of(80, -10, right), BoardAnchor.of(80, -10, top)));
				G.put(BoardAnchor.of(80, -10, right),
						newSet(BoardAnchor.of(80, -10, left), BoardAnchor.of(80, -10, bottom), BoardAnchor.of(80, -10, top)));
				G.put(BoardAnchor.of(80, -10, top),
						newSet(BoardAnchor.of(80, -10, left), BoardAnchor.of(80, -10, bottom), BoardAnchor.of(80, -10, right)));
				
				String sNoNeighbors = "Es wird false zurückgegeben, obwohl die Nachbarpositionen leer sind";
				// Test ═
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, lineHoriz), sNoNeighbors);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 7, lineHoriz), sNoNeighbors);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 0, lineHoriz), sNoNeighbors);
				// Test ║
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, lineVert), sNoNeighbors);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 8, 4, lineVert), sNoNeighbors);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 0, lineVert), sNoNeighbors);
				// Test ╬
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, plus), sNoNeighbors);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -7, 2, plus), sNoNeighbors);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 0, plus), sNoNeighbors);
				// Test ┼
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, deadPlus), sNoNeighbors);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -7, -9, deadPlus), sNoNeighbors);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 0, deadPlus), sNoNeighbors);
				// Test Start
				String sStartNoNeighbors = "Beim Überprüfen einer Startkarte wird false zurückgegeben, obwohl die Nachbarpositionen leer sind";
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, start), sStartNoNeighbors);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 8, -9, start), sStartNoNeighbors);
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 0, start), sStartNoNeighbors);
				
				
				/*
				 * Notiz:
				 * Der folgende Test wird gemacht, da er meistens erfolgreich sein
				 * sollte, wodurch man nicht explizit in den Code schauen muss.
				 * Allerdings kann es vorkommen, dass man Positionen ohne Karte
				 * korrekt behandelt, aber einen Fehler beim Kompatibilitätstest
				 * gemacht hat. In diesem Fall muss man doch nochmals in den Code
				 * schauen.
				 */
				//@formatter:off
				/*
				 *   ┐  ?
				 * 
				 */
				//@formatter:on
				
				board.clear();
				G.clear();
				PathCard B = createCard(Map.of(left, newSet(), bottom, newSet()));
				board.put(Position.of(80, -10), B);
				G.put(BoardAnchor.of(80, -10, left), newSet());
				G.put(BoardAnchor.of(80, -10, bottom), newSet());
				
				try {
					// Test ═
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 81, -10, lineHoriz));
					// Test ║
					assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 81, -10, lineVert));
					// Test ╬
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 81, -10, plus));
					// Test ┼
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 81, -10, deadPlus));
					// Test Start
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 81, -10, start));
				} catch (AssertionError e) {
					// wird nur angezeigt, wenn es ein Problem gab
					List<String> msg = new ArrayList<>();
					msg.add("!! In den Code schauen !!");
					msg.add("!! In den Code schauen !!");
					msg.add("");
					msg.add("Da für leere Positionen immer true");
					msg.add("erwartet wird, wurden weitere Tests");
					msg.add("gemacht. Einer davon ist fehl-");
					msg.add("geschlagen, trotzdem kann es den");
					msg.add("Punkt geben für DIESEN Test geben.");
					msg.add("");
					msg.add("Wenn EINE (1) leere Position gefunden wird,");
					msg.add("muss trotzdem weitergesucht werden.");
					msg.add("Es darf nicht nach der erste leeren Position");
					msg.add("direkt true zurückgegeben werden.");
					msg.add("");
					msg.add("Das KÖNNTE so aussehen:");
					msg.add("if (board.get(neighbor) == null) continue;");
					msg.add("");
					msg.add("Wenn das OK ist, wird der Punkt vergeben.");
					msg.add("Die restlichen Tests waren erfolgreich.");
					msg.add("");
					fail(msg.stream().collect(Collectors.joining("\n")), e);
				}
			}
			
			/**
			 * {@link fop.model.board.Gameboard#doesCardMatchItsNeighbors(int, int, PathCard)}
			 */
			private void helperVerdeckteZielkarte(int x, int y, CardAnchor ca) throws Exception {
				//@formatter:off
				/*
				 * X @ (x, y) = verdeckte Zielkarte (leerer Graph)
				 * ? @ (x+dx, y+dy)
				 */
				//@formatter:on
				
				Position d = ca.getAdjacentPosition(Position.of(0, 0));
				int dx = d.x();
				int dy = d.y();
				
				Gameboard gameboard = new Gameboard();
				setAttribute(gameboard, "graph", new SolutionGraph<>());
				Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
				
				GoalCard X = new GoalCard(GoalCard.Type.Stone);
				board.put(Position.of(x, y), X);
				
				String sCovered = "Verdeckte Zielkarten werden nicht korrekt behandelt";
				// Test ═
				PathCard lineHoriz = createLineHoriz();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", x + dx, y + dy, lineHoriz), sCovered);
				// Test ║
				PathCard lineVert = createLineVert();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", x + dx, y + dy, lineVert), sCovered);
				// Test ╬
				PathCard plus = createPlus();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", x + dx, y + dy, plus), sCovered);
				// Test ┼
				PathCard deadPlus = createDeadPlus();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", x + dx, y + dy, deadPlus), sCovered);
				// Test Start
				PathCard start = createStart();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", x + dx, y + dy, start),
						"Eine Startkarte neben einer verdeckten Zielkarte wird nicht korrekt behandelt");
			}
			
			/**
			 * {@link fop.model.board.Gameboard#doesCardMatchItsNeighbors(int, int, PathCard)}
			 */
			@Test
			@DisplayName("(*) Zielkarte")
			public void m3() throws Exception {
				// verdeckte Zielkarte, alles passt
				// Da alle true erwarten folgen weitere Tests
				helperVerdeckteZielkarte(8, -2, right);
				helperVerdeckteZielkarte(8, 0, left);
				helperVerdeckteZielkarte(8, 2, bottom);
				
				helperVerdeckteZielkarte(3, 6, top);
				helperVerdeckteZielkarte(-8, 14, right);
				helperVerdeckteZielkarte(0, 0, left);
				
				/*
				 * Notiz:
				 * Die folgenden Tests werden gemacht, da sie meistens
				 * erfolgreich sein sollten, wodurch man nicht explizit
				 * in den Code schauen muss. Allerdings kann es vor-
				 * kommen, dass man zwar die Zielkarte korrekt behandelt
				 * (verdeckt -> wie leer, aufgedeckt -> wie Wegekarte),
				 * aber einen Fehler beim Kompatibilitätstest für
				 * Wegekarten gemacht hat. Daher muss beim Fehlschlagen
				 * eines Tests doch in den Code geschaut werden.
				 */
				
				try {
					// verdeckte Zielkarte, aber passt trotzdem nicht
					
					//@formatter:off
					/*
					 *    ═
					 * 
					 * X  ?
					 *
					 * X = verdeckte Zielkarte (kein Graph)
					 */
					//@formatter:on
					
					Gameboard gameboard = new Gameboard();
					Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
					Graph<BoardAnchor> graph = new SolutionGraph<>();
					setAttribute(gameboard, "graph", graph);
					Map<BoardAnchor, Set<BoardAnchor>> G = (Map<BoardAnchor, Set<BoardAnchor>>) getAttribute(graph, "G");
					
					GoalCard X = new GoalCard(GoalCard.Type.Stone);
					board.put(Position.of(2, 5), X);
					PathCard Y = createLineHoriz();
					board.put(Position.of(3, 4), Y);
					G.put(BoardAnchor.of(3, 4, left), newSet(BoardAnchor.of(3, 4, right)));
					G.put(BoardAnchor.of(3, 4, right), newSet(BoardAnchor.of(2, 5, left)));
					
					// Test ═
					PathCard lineHoriz = createLineHoriz();
					assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 5, lineHoriz));
					// Test ║
					PathCard lineVert = createLineVert();
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 5, lineVert));
					// Test ╬
					PathCard plus = createPlus();
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 5, plus));
					// Test ┼
					PathCard deadPlus = createDeadPlus();
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 5, deadPlus));
					// Test Start
					PathCard start = createStart();
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 5, start));
					
					//@formatter:off
					/*
					 * X  ?  ║
					 */
					//@formatter:on
					
					board.clear();
					G.clear();
					board.put(Position.of(6, -1), X);
					PathCard Z = createLineVert();
					board.put(Position.of(8, -1), Z);
					G.put(BoardAnchor.of(8, -1, bottom), newSet(BoardAnchor.of(8, -1, top)));
					G.put(BoardAnchor.of(8, -1, top), newSet(BoardAnchor.of(2, 5, bottom)));
					
					// Test ═
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 7, -1, lineHoriz));
					// Test ║
					assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 7, -1, lineVert));
					// Test ╬
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 7, -1, plus));
					// Test ┼
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 7, -1, deadPlus));
					// Test Start
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 7, -1, start));
					
					
					//@formatter:off
					/*
					 * X  ?
					 * 
					 *    ═
					 */
					//@formatter:on
					
					board.clear();
					G.clear();
					board.put(Position.of(-2, 3), X);
					board.put(Position.of(-1, 4), Y);
					G.put(BoardAnchor.of(-1, 4, left), newSet(BoardAnchor.of(-1, 4, right)));
					G.put(BoardAnchor.of(-1, 4, right), newSet(BoardAnchor.of(2, 5, left)));
					
					// Test ═
					assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 3, lineHoriz));
					// Test ║
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 3, lineVert));
					// Test ╬
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 3, plus));
					// Test ┼
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 3, deadPlus));
					// Test Start
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 3, start));
					
					
					//@formatter:off
					/*
					 * ║  ?  X
					 */
					//@formatter:on
					
					board.clear();
					G.clear();
					board.put(Position.of(10, -1), X);
					board.put(Position.of(8, -1), Z);
					G.put(BoardAnchor.of(8, -1, bottom), newSet(BoardAnchor.of(8, -1, top)));
					G.put(BoardAnchor.of(8, -1, top), newSet(BoardAnchor.of(2, 5, bottom)));
					
					// Test ═
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 9, -1, lineHoriz));
					// Test ║
					assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 9, -1, lineVert));
					// Test ╬
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 9, -1, plus));
					// Test ┼
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 9, -1, deadPlus));
					// Test Start
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 9, -1, start));
					
					
					// aufgedeckte Zielkarte, wie Wegekarte, nicht alles passt
					
					//@formatter:off
					/*
					 * X  ?
					 * 
					 * X = NICHT verdeckte Zielkarte (╬ Graph)
					 */
					//@formatter:on
					
					board.clear();
					G.clear();
					X.showFront();
					board.put(Position.of(2, 5), X);
					Graph<CardAnchor> cardGraph = (Graph<CardAnchor>) getAttribute(X, "graph");
					Map<CardAnchor, Set<CardAnchor>> cardG = (Map<CardAnchor, Set<CardAnchor>>) getAttribute(cardGraph, "G");
					cardG.put(left, newSet(bottom, right, top));
					cardG.put(bottom, newSet(left, right, top));
					cardG.put(right, newSet(left, bottom, top));
					cardG.put(top, newSet(left, bottom, right));
					G.put(BoardAnchor.of(2, 5, left),
							newSet(BoardAnchor.of(2, 5, bottom), BoardAnchor.of(2, 5, right), BoardAnchor.of(2, 5, top)));
					G.put(BoardAnchor.of(2, 5, bottom),
							newSet(BoardAnchor.of(2, 5, left), BoardAnchor.of(2, 5, right), BoardAnchor.of(2, 5, top)));
					G.put(BoardAnchor.of(2, 5, right),
							newSet(BoardAnchor.of(2, 5, left), BoardAnchor.of(2, 5, bottom), BoardAnchor.of(2, 5, top)));
					G.put(BoardAnchor.of(2, 5, top),
							newSet(BoardAnchor.of(2, 5, left), BoardAnchor.of(2, 5, bottom), BoardAnchor.of(2, 5, right)));
					
					// Test ═
					assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 5, lineHoriz));
					// Test ║
					assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 5, lineVert));
					// Test ╬
					assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 5, plus));
					// Test ┼
					assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 5, deadPlus));
					// Test Start
					assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 5, start));
				} catch (AssertionError e) {
					// wird nur angezeigt, wenn es ein Problem gab
					List<String> msg = new ArrayList<>();
					msg.add("!! In den Code schauen !!");
					msg.add("!! In den Code schauen !!");
					msg.add("");
					msg.add("Eine aufgedeckte Zielkarte wurde nicht");
					msg.add("korrekt behandelt. Trotzdem kann es den");
					msg.add("Punkt für DIESEN Test geben.");
					msg.add("");
					msg.add("Eine verdeckte Zielkarte muss so behandelt");
					msg.add("werden wie eine Position ohne Karte.");
					msg.add("");
					msg.add("Das KÖNNTE so aussehen:");
					msg.add("if (card.isGoalCard()");
					msg.add("     && ((GoalCard) card).isCovered())");
					msg.add("   continue;");
					msg.add("");
					msg.add("Wenn das OK ist, wird der Punkt vergeben.");
					msg.add("Die restlichen Tests waren erfolgreich.");
					msg.add("");
					fail(msg.stream().collect(Collectors.joining("\n")), e);
				}
			}
			
			/**
			 * {@link fop.model.board.Gameboard#doesCardMatchItsNeighbors(int, int, PathCard)}
			 */
			@Test
			@DisplayName("Anker -> Anker")
			public void m4() throws Exception {
				/*
				 * Notiz:
				 * Der Test ist erfolgreich sobald die Ankerpositionen für
				 * eine Seite korrekt funktionieren. Dadurch ist der Test
				 * unabhängig vom letzten Test, dass alle benachbarten Karten
				 * funktionieren müssen.
				 */
				
				AssertionError firstError = null;
				for (CardAnchor ca : CardAnchor.values())
					try {
						//@formatter:off
						/*
						 * ╬ @ (2, 9)
						 * ? @ (2+dx, 9+dy)
						 */
						//@formatter:on
						
						Position d = ca.getAdjacentPosition(Position.of(0, 0));
						int dx = d.x();
						int dy = d.y();
						
						Gameboard gameboard = new Gameboard();
						Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
						Graph<BoardAnchor> graph = new SolutionGraph<>();
						setAttribute(gameboard, "graph", graph);
						Map<BoardAnchor, Set<BoardAnchor>> G = (Map<BoardAnchor, Set<BoardAnchor>>) getAttribute(graph, "G");
						
						PathCard X = createPlus();
						board.put(Position.of(2, 9), X);
						G.put(BoardAnchor.of(2, 9, left),
								newSet(BoardAnchor.of(2, 9, bottom), BoardAnchor.of(2, 9, right), BoardAnchor.of(2, 9, top)));
						G.put(BoardAnchor.of(2, 9, bottom),
								newSet(BoardAnchor.of(2, 9, left), BoardAnchor.of(2, 9, right), BoardAnchor.of(2, 9, top)));
						G.put(BoardAnchor.of(2, 9, right),
								newSet(BoardAnchor.of(2, 9, left), BoardAnchor.of(2, 9, bottom), BoardAnchor.of(2, 9, top)));
						G.put(BoardAnchor.of(2, 9, top),
								newSet(BoardAnchor.of(2, 9, left), BoardAnchor.of(2, 9, bottom), BoardAnchor.of(2, 9, right)));
						
						String s = "Es wird nicht geprüft, dass ein entsprechender Ankerpunkt vorhanden ist, wenn die Nachbarkarte einen angrenzenden Ankerpunkt besitzt";
						// Test ═
						PathCard lineHoriz = createLineHoriz();
						assertEquals(dx != 0 && dy == 0, (boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2 + dx, 9 + dy, lineHoriz), s);
						// Test ║
						PathCard lineVert = createLineVert();
						assertEquals(dy != 0 && dx == 0, (boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2 + dx, 9 + dy, lineVert), s);
						// Test ╬
						PathCard plus = createPlus();
						assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2 + dx, 9 + dy, plus), s);
						// Test ┼
						PathCard deadPlus = createDeadPlus();
						assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2 + dx, 9 + dy, deadPlus), s);
						// Test Start
						PathCard start = createStart();
						assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2 + dx, 9 + dy, start), s);
						
						// einmal durch -> Erfolg
						return;
					} catch (AssertionError e) {
						// mit der nächsten Seite versuchen
						if (firstError == null) firstError = e;
					}
				
				// wenn man hier ist, sind alle Seiten fehlgeschlagen
				throw firstError;
			}
			
			/**
			 * {@link fop.model.board.Gameboard#doesCardMatchItsNeighbors(int, int, PathCard)}
			 */
			@Test
			@DisplayName("kein Anker -> kein Anker")
			public void m5() throws Exception {
				/*
				 * Notiz:
				 * Der Test ist erfolgreich sobald die Ankerpositionen für
				 * eine Seite korrekt funktionieren. Dadurch ist der Test
				 * unabhängig vom letzten Test, dass alle benachbarten Karten
				 * funktionieren müssen.
				 */
				
				AssertionError firstError = null;
				for (CardAnchor ca : CardAnchor.values())
					try {
						//@formatter:off
						/*
						 * o @ (2, 9) = Karte ohne Ankerpunkte
						 * ? @ (2+dx, 9+dy)
						 */
						//@formatter:on
						
						Position d = ca.getAdjacentPosition(Position.of(0, 0));
						int dx = d.x();
						int dy = d.y();
						
						Gameboard gameboard = new Gameboard();
						setAttribute(gameboard, "graph", new SolutionGraph<>());
						Map<Position, PathCard> board = (Map<Position, PathCard>) getAttribute(gameboard, "board");
						
						PathCard X = createCard(Map.of());
						board.put(Position.of(2, 9), X);
						
						String s = "Es wird nicht geprüft, dass kein entsprechender Ankerpunkt vorhanden sein darf, wenn die Nachbarkarte keinen angrenzenden Ankerpunkt besitzt";
						// Test ═
						PathCard lineHoriz = createLineHoriz();
						assertEquals(dx == 0 && dy != 0, (boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2 + dx, 9 + dy, lineHoriz), s);
						// Test ║
						PathCard lineVert = createLineVert();
						assertEquals(dy == 0 && dx != 0, (boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2 + dx, 9 + dy, lineVert), s);
						// Test ╬
						PathCard plus = createPlus();
						assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2 + dx, 9 + dy, plus), s);
						// Test ┼
						PathCard deadPlus = createDeadPlus();
						assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2 + dx, 9 + dy, deadPlus), s);
						// Test Start
						PathCard start = createStart();
						assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2 + dx, 9 + dy, start), s);
						
						// einmal durch -> Erfolg
						return;
					} catch (AssertionError e) {
						// mit der nächsten Seite versuchen
						if (firstError == null) firstError = e;
					}
				
				// wenn man hier ist, sind alle Seiten fehlgeschlagen
				throw firstError;
			}
			
			/**
			 * {@link fop.model.board.Gameboard#doesCardMatchItsNeighbors(int, int, PathCard)}
			 */
			@Test
			@DisplayName("vollständig korrekt")
			public void m6() throws Exception {
				Gameboard gameboard = createLargeTestGameboard();
				
				//@formatter:off
				/*
				 *       ╠     ╬
				 * 
				 * ╤  S  ╬  ╦  ╧  ╬
				 * 
				 *          ╝
				 *    ╦
				 */
				//@formatter:on
				
				// Test ═
				PathCard lineHoriz = createLineHoriz();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, -2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, -2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, -2, lineHoriz));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, -2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, -2, lineHoriz));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, -2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, -2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, -2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, -1, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, -1, lineHoriz));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, -1, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, -1, lineHoriz));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, -1, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, -1, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 0, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 0, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 1, lineHoriz));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 1, lineHoriz));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 1, lineHoriz));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, 1, lineHoriz));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 1, lineHoriz));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 1, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 1, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, 2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, 2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, lineHoriz));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 2, lineHoriz));
				
				// Test ║
				PathCard lineVert = createLineVert();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, -2, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, -2, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, -2, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, -2, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, -2, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, -2, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, -2, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, -2, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, -1, lineVert));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, -1, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, -1, lineVert));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, -1, lineVert));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, -1, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, -1, lineVert));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 0, lineVert));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 0, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 1, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 1, lineVert));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 1, lineVert));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, 1, lineVert));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 1, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 1, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 1, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 2, lineVert));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 2, lineVert));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, 2, lineVert));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, 2, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 2, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, lineVert));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 2, lineVert));
				
				// Test ╬
				PathCard plus = createPlus();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, -2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, -2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, -2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, -2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, -2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, -2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, -2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, -2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, -1, plus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, -1, plus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, -1, plus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, -1, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, -1, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, -1, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 0, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 0, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 1, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 1, plus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 1, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, 1, plus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 1, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 1, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 1, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, 2, plus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, 2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, plus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 2, plus));
				
				// Test ╔
				PathCard curve = createCard(Map.of(bottom, newSet(right), right, newSet(bottom)));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, -2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, -2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, -2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, -2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, -2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, -2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, -2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, -2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, -1, curve));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, -1, curve));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, -1, curve));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, -1, curve));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, -1, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, -1, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 0, curve));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 0, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 1, curve));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 1, curve));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 1, curve));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, 1, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 1, curve));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 1, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 1, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 2, curve));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, 2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, 2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, curve));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 2, curve));
				
				// Test ┼
				PathCard deadPlus = createDeadPlus();
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, -2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, -2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, -2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, -2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, -2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, -2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, -2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, -2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, -1, deadPlus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, -1, deadPlus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, -1, deadPlus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, -1, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, -1, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, -1, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 0, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 0, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 1, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 1, deadPlus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 0, 1, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, 1, deadPlus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 1, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 1, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 1, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -2, 2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", -1, 2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 1, 2, deadPlus));
				assertFalse((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 2, 2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 3, 2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 4, 2, deadPlus));
				assertTrue((boolean) callMethod(gameboard, "doesCardMatchItsNeighbors", 5, 2, deadPlus));
			}
			
		}
		
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	//===========================================================================================//
	//===========================================================================================//
	///////////////////////////////////////////////////////////////////////////////////////////////
	
	@Nested
	@DisplayName("Aufgabe 4.2")
	public class A2 {
		
		@Nested
		@DisplayName("Aufgabe 4.2.1")
		public class A21 {
			
			public A21() {}
			
			/**
			 * {@link fop.model.ScoreEntry#read(String)}
			 */
			@Test
			@DisplayName("read: gültige Strings")
			public void m1() {
				ScoreEntry se = new ScoreEntry("Dominik", LocalDateTime.of(2020, 6, 15, 19, 23, 27, 818535900), 61);
				assertEquals(se, ScoreEntry.read("Dominik;2020-06-15T19:23:27.818535900;61"),
						"Der Highscore-Eintrag wird nicht korrekt umgewandelt");
				
				se = new ScoreEntry("Ganz langer Name", LocalDateTime.of(1906, 12, 9, 2, 1, 0), 104);
				assertEquals(se, ScoreEntry.read("Ganz langer Name;1906-12-09T02:01:00;104"),
						"Einträge mit langen Namen werden nicht korrekt umgewandelt");
				
				se = new ScoreEntry("Negative Punkte", LocalDateTime.of(2021, 5, 5, 13, 5, 26), -13);
				assertEquals(se, ScoreEntry.read("Negative Punkte;2021-05-05T13:05:26;-13"),
						"Einträge mit negativer Punktzahl werden nicht korrekt umgewandelt");
				
				se = new ScoreEntry("", LocalDateTime.of(0, 1, 1, 0, 0), 0);
				assertEquals(se, ScoreEntry.read(";0000-01-01T00:00:00;0"),
						"Einträge ohne Namen werden nicht korrekt umgewandelt");
			}
			
			/**
			 * {@link fop.model.ScoreEntry#read(String)}
			 */
			@Test
			@DisplayName("read: ungültige Strings")
			public void m2() {
				assertNull(ScoreEntry.read("Ein Semikolon; zu wenig"),
						"Ein fehlendes Semikolon wird nicht korrekt behandelt");
				assertNull(ScoreEntry.read("Name;2020-01-01T00:00:00;12;mehr Infos als nötig"),
						"Einträge mit mehr als drei Semikola werden nicht korrekt behandelt");
				assertNull(ScoreEntry.read("Name;kein Datum;23"),
						"Ein ungültiges Datum wird nicht korrekt behandelt");
				assertNull(ScoreEntry.read("Name;2020-12-24T22:00:00;keine Punktzahl"),
						"Einträge mit ungültiger Punktzahl werdne nicht korrekt behandelt");
			}
			
			/**
			 * {@link fop.model.ScoreEntry#write(PrintWriter)}
			 */
			@Test
			@DisplayName("write")
			public void m3() {
				StringWriter output = new StringWriter();
				PrintWriter printWriter = new PrintWriter(output);
				
				ScoreEntry se = new ScoreEntry("Dominik", LocalDateTime.of(2020, 6, 15, 19, 23, 27, 818535900), 61);
				se.write(printWriter);
				assertEquals("Dominik;2020-06-15T19:23:27.818535900;61" + System.lineSeparator(), output.toString(),
						"Der Highscore-Eintrag wird nicht korrekt geschrieben");
				output.getBuffer().setLength(0);
				
				se = new ScoreEntry("Sehr langer Name", LocalDateTime.of(1906, 8, 9, 6, 1, 6), 104);
				se.write(printWriter);
				assertEquals("Sehr langer Name;1906-08-09T06:01:06;104" + System.lineSeparator(), output.toString(),
						"Einträge mit langen Namen werden nicht korrekt geschrieben");
				output.getBuffer().setLength(0);
				
				se = new ScoreEntry("Negative Punktzahl", LocalDateTime.of(2006, 9, 9, 13, 5, 26), -13);
				se.write(printWriter);
				assertEquals("Negative Punktzahl;2006-09-09T13:05:26;-13" + System.lineSeparator(), output.toString(),
						"Einträge mit negativer Punktzahl werden nicht korrekt geschrieben");
				output.getBuffer().setLength(0);
				
				se = new ScoreEntry("", LocalDateTime.of(1, 1, 1, 1, 1, 1), 1);
				se.write(printWriter);
				assertEquals(";0001-01-01T01:01:01;1" + System.lineSeparator(), output.toString(),
						"Einträge ohne Namen werden nicht korrekt geschrieben");
				output.getBuffer().setLength(0);
			}
			
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		private String writeToFile(String... lines) throws IOException {
			File file = new File(createFile());
			try (PrintWriter out = new PrintWriter(file)) {
				for (String line : lines)
					out.println(line);
			}
			return file.getAbsolutePath();
		}
		
		private String createFile() throws IOException {
			return File.createTempFile("tests", ".txt").getAbsolutePath();
		}
		
		private List<String> readFromFile(String path) throws IOException {
			try (BufferedReader in = new BufferedReader(new FileReader(new File(path)))) {
				List<String> l = new ArrayList<>();
				String line;
				while ((line = in.readLine()) != null)
					l.add(line);
				return l;
			}
		}
		
		private void deleteFile(String path) {
			try {
				Files.delete(Path.of(path));
			} catch (NoSuchFileException e) {
				fail("Die Datei wurde nicht erstellt");
			} catch (FileSystemException e) {
				System.out.println("[Warning] Der PrintWriter/Scanner/etc. wurde nicht geschlossen");
				// kein fail, da das keinen Punktabzug geben soll
			} catch (Exception e) {
				fail("Die Datei konnte nicht gelöscht werden");
			}
		}
		
		private List<ScoreEntry> parseScoreEntries(List<String> lines) {
			List<ScoreEntry> scoreEntries = new ArrayList<>();
			for (String line : lines) {
				String[] part = line.split(";");
				if (part.length != 3) return null;
				
				try {
					String name = part[0];
					LocalDateTime date = LocalDateTime.parse(part[1]);
					int score = Integer.parseInt(part[2]);
					scoreEntries.add(new ScoreEntry(name, date, score));
				} catch (DateTimeParseException | NumberFormatException | ArrayIndexOutOfBoundsException e) {
					scoreEntries.add(null);
				}
			}
			return scoreEntries;
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		@Nested
		@DisplayName("Aufgabe 4.2.2")
		public class A22 {
			
			public A22() {}
			
			/**
			 * {@link fop.io.ScoreEntryIO#loadScoreEntries()}
			 */
			@Test
			@DisplayName("load: gültige Dateien")
			public void m1() throws IOException {
				// Normale Datei
				String s = "Gültige Dateien werden nicht korrekt eingelesen";
				String path = writeToFile(
						"Dominik;2020-06-15T19:23:27;61",
						"Spieler 2;2020-06-15T20:57:34;20",
						"Spieler 3;2020-06-15T21:13:43;24");
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				assertEquals(List.of(
						new ScoreEntry("Dominik", LocalDateTime.of(2020, 6, 15, 19, 23, 27), 61),
						new ScoreEntry("Spieler 2", LocalDateTime.of(2020, 6, 15, 20, 57, 34), 20),
						new ScoreEntry("Spieler 3", LocalDateTime.of(2020, 6, 15, 21, 13, 43), 24)),
						ScoreEntryIO.loadScoreEntries(), s);
				deleteFile(path);
				
				// Nur eine Zeile
				path = writeToFile("Vorname Nachname;1956-09-10T15:30:20;99");
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				assertEquals(List.of(
						new ScoreEntry("Vorname Nachname", LocalDateTime.of(1956, 9, 10, 15, 30, 20), 99)),
						ScoreEntryIO.loadScoreEntries(), s);
				deleteFile(path);
				
				// Leere Datei
				String sEmpty = "Leere Dateien werden nicht korrekt eingelesen";
				path = writeToFile();
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				assertEquals(List.of(), ScoreEntryIO.loadScoreEntries(), sEmpty);
				deleteFile(path);
			}
			
			/**
			 * {@link fop.io.ScoreEntryIO#loadScoreEntries()}
			 */
			@Test
			@DisplayName("load: ungültige Einträge, fehlende Datei")
			public void m2() throws IOException {
				ScoreEntry valid = new ScoreEntry("Gültig", LocalDateTime.of(2020, 10, 10, 10, 10, 10), 10);
				
				//== Ungültige Einträge ==//
				
				String sInvalid = "Ungültige Einträge werden nicht aus der Liste entfernt";
				String sValid = "Die gültigen Einträge werden nicht korrekt eingelesen";
				
				// Zu wenig
				String path = writeToFile(
						"Gültig;2020-10-10T10:10:10;10",
						"Zu wenig; Informationen",
						"Gültig;2020-10-10T10:10:10;10");
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				List<ScoreEntry> res = ScoreEntryIO.loadScoreEntries();
				assertFalse(res.contains(null), sInvalid);
				assertEquals(List.of(valid, valid), res, sValid);
				deleteFile(path);
				
				// Zu viel
				path = writeToFile(
						"Gültig;2020-10-10T10:10:10;10",
						"Ungültig;2020-09-09T09:09:09;9;zu viel");
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				res = ScoreEntryIO.loadScoreEntries();
				assertFalse(res.contains(null), sInvalid);
				assertEquals(List.of(valid), res, sValid);
				deleteFile(path);
				
				// Ungültiges Datum
				path = writeToFile(
						"Ungültig;KEIN Datum;9;zu viel",
						"Gültig;2020-10-10T10:10:10;10");
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				res = ScoreEntryIO.loadScoreEntries();
				assertFalse(res.contains(null), sInvalid);
				assertEquals(List.of(valid), res, sValid);
				deleteFile(path);
				
				// Ungültige Punktzahl
				path = writeToFile(
						"Gültig;2020-10-10T10:10:10;10",
						"Gültig;2020-10-10T10:10:10;10",
						"Ungültig;2020-09-09T09:09:09;KeinePunkte");
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				res = ScoreEntryIO.loadScoreEntries();
				assertFalse(res.contains(null), sInvalid);
				assertEquals(List.of(valid, valid), res, sValid);
				deleteFile(path);
				
				//== Fehlende Datei ==//
				
				// sicherstellen, dass die Datei nicht existiert
				path = createFile();
				deleteFile(path);
				
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				assertEquals(List.of(), ScoreEntryIO.loadScoreEntries(), "Für eine fehlende Datei wird keine leere Liste ausgegeben");
			}
			
			/**
			 * {@link fop.io.ScoreEntryIO#writeScoreEntries(List)}
			 */
			@Test
			@DisplayName("write")
			public void m3() throws IOException {
				// Normale Einträge
				List<ScoreEntry> scoreEntries = List.of(
						new ScoreEntry("Vorname Nachname", LocalDateTime.of(2015, 3, 20, 15, 23, 40), 242),
						new ScoreEntry("Nachname, Vorname", LocalDateTime.of(2042, 6, 15, 20, 12), 120),
						new ScoreEntry("Ein Spieler", LocalDateTime.of(2019, 4, 4, 2, 6, 57), 10));
				String path = createFile();
				deleteFile(path);
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				ScoreEntryIO.writeScoreEntries(scoreEntries);
				assertEquals(scoreEntries, parseScoreEntries(readFromFile(path)),
						"Die Einträge werden nicht korrekt geschrieben");
				deleteFile(path);
				
				// Nur eine Zeile
				scoreEntries = List.of(new ScoreEntry("Name", LocalDateTime.of(2020, 8, 8, 12, 12, 59), 0));
				path = createFile();
				deleteFile(path);
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				ScoreEntryIO.writeScoreEntries(scoreEntries);
				assertEquals(scoreEntries, parseScoreEntries(readFromFile(path)),
						"Die Einträge werden nicht korrekt geschrieben, wenn nur ein Eintrag geschrieben werden soll");
				deleteFile(path);
				
				// Keine Einträge
				scoreEntries = List.of();
				path = createFile();
				deleteFile(path);
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				ScoreEntryIO.writeScoreEntries(scoreEntries);
				assertEquals(List.of(), readFromFile(path), "Die Methode ist nicht korrekt, wenn eine leere Liste übergeben wird");
				deleteFile(path);
				
				// Datei bereits vorhanden
				scoreEntries = List.of(new ScoreEntry("Vorname Nachname", LocalDateTime.of(2015, 3, 20, 15, 23), 242));
				path = writeToFile(
						"Komplett egal,",
						"was in dieser Datei steht,",
						"da sie überschrieben werden soll.");
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				ScoreEntryIO.writeScoreEntries(scoreEntries);
				assertEquals(scoreEntries, parseScoreEntries(readFromFile(path)),
						"Die Einträge werden nicht korrekt geschrieben, wenn die Datei bereits vorhanden ist");
				deleteFile(path);
			}
			
		}
		
		///////////////////////////////////////////////////////////////////////////////////////////////
		///////////////////////////////////////////////////////////////////////////////////////////////
		
		@Nested
		@DisplayName("Aufgabe 4.2.3")
		public class A23 {
			
			public A23() {}
			
			/**
			 * {@link fop.io.ScoreEntryIO#addScoreEntry(ScoreEntry)}
			 */
			@Test
			@DisplayName("addScoreEntry")
			public void m1() throws IOException {
				ScoreEntry se52 = new ScoreEntry("Zweiundfünfzig Punkte", LocalDateTime.of(2020, 1, 1, 0, 0, 0), 52);
				ScoreEntry se50 = new ScoreEntry("Fünfzig Punkte", LocalDateTime.of(2020, 1, 1, 1, 1, 1), 50);
				ScoreEntry se10a = new ScoreEntry("A", LocalDateTime.of(2020, 1, 2, 3, 4, 5), 10);
				ScoreEntry se10b = new ScoreEntry("B", LocalDateTime.of(2020, 1, 1, 1, 1, 1), 10);
				ScoreEntry se10c = new ScoreEntry("C", LocalDateTime.of(2020, 5, 4, 3, 2, 1), 10);
				ScoreEntry se0 = new ScoreEntry("Null Punkte", LocalDateTime.of(2020, 1, 1, 0, 1, 0), 0);
				
				String s_se52 = "Zweiundfünfzig Punkte;2020-01-01T00:00:00;52";
				String s_se50 = "Fünfzig Punkte;2020-01-01T01:01:01;50";
				String s_se10a = "A;2020-01-02T03:04:05;10";
				String s_se10b = "B;2020-01-01T01:01:01;10";
				String s_se0 = "Null Punkte;2020-01-01T00:01:00;0";
				
				// In der Mitte einfügen
				String path = writeToFile(s_se52, s_se50, s_se0);
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				ScoreEntryIO.addScoreEntry(se10a);
				List<ScoreEntry> res = parseScoreEntries(readFromFile(path));
				assertTrue(res.contains(se10a),
						"Das neue Element wird nicht eingefügt");
				assertEquals(List.of(se52, se50, se10a, se0),
						res, "Das neue Element wird nicht korrekt eingefügt");
				deleteFile(path);
				
				// In leere Datei einfügen
				path = writeToFile();
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				ScoreEntryIO.addScoreEntry(se50);
				res = parseScoreEntries(readFromFile(path));
				assertTrue(res.contains(se50),
						"Das Element wird nicht in eine leere Datei eingefügt");
				assertEquals(List.of(se50),
						res, "Das neue Element wird nicht korrekt in eine leere Datei eingefügt");
				deleteFile(path);
				
				// Am Anfang einfügen
				path = writeToFile(s_se50, s_se10b, s_se0);
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				ScoreEntryIO.addScoreEntry(se52);
				res = parseScoreEntries(readFromFile(path));
				assertTrue(res.contains(se52),
						"Das neue Element wird nicht eingefügt, wenn es das größte Element ist");
				assertEquals(List.of(se52, se50, se10b, se0),
						res, "Das neue Element wird nicht korrekt eingefügt, wenn es das größte Element ist");
				deleteFile(path);
				
				// Am Ende einfügen
				path = writeToFile(s_se50, s_se10b);
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				ScoreEntryIO.addScoreEntry(se0);
				res = parseScoreEntries(readFromFile(path));
				assertTrue(res.contains(se0),
						"Das neue Element wird nicht eingefügt, wenn es das kleinste Element ist");
				assertEquals(List.of(se50, se10b, se0),
						res, "Das neue Element wird nicht korrekt eingefügt, wenn es das kleinste Element ist");
				deleteFile(path);
				
				// Zwei gleiche Werte, danach einfügen
				path = writeToFile(s_se50, s_se10a, s_se0);
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				ScoreEntryIO.addScoreEntry(se10b);
				res = parseScoreEntries(readFromFile(path));
				assertTrue(res.contains(se10b),
						"Das neue Element wird nicht eingefügt, wenn es denselben Wert wie ein vorhandenes Element hat");
				assertEquals(List.of(se50, se10a, se10b, se0),
						res, "Das neue Element wird nicht korrekt NACH dem Element mit derselben Punktzahl eingefügt");
				deleteFile(path);
				
				// Drei gleiche Werte, danach einfügen
				path = writeToFile(s_se50, s_se10a, s_se10b, s_se0);
				setStaticAttribute(ScoreEntryIO.class, "PATH", path);
				ScoreEntryIO.addScoreEntry(se10c);
				res = parseScoreEntries(readFromFile(path));
				assertTrue(res.contains(se10c),
						"Das neue Element wird nicht eingefügt, wenn es denselben Wert wie ein vorhandenes Element hat");
				assertEquals(List.of(se50, se10a, se10b, se10c, se0),
						res, "Das neue Element wird nicht korrekt NACH dem Element mit derselben Punktzahl eingefügt");
				deleteFile(path);
			}
			
		}
		
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////
	//===========================================================================================//
	//===========================================================================================//
	///////////////////////////////////////////////////////////////////////////////////////////////
	
	@Nested
	@DisplayName("Aufgabe 4.3")
	public class A3 {
		
		@Nested
		@DisplayName("Aufgabe 4.3.2")
		public class A32 {
			
			public A32() {}
			
			/**
			 * {@link fop.model.Player.Role}
			 */
			@Test
			@DisplayName("Enum und Bild")
			public void m1() {
				assertTrue(Role.values().length > 2, "Es wurde keine Rolle hinzugefügt.");
				Role newRole = Arrays.stream(Role.values()).filter(r -> r != Role.GOLD_MINER && r != Role.SABOTEUR).findFirst().get();
				String PATH = (String) getStaticAttribute(CardImageReader.class, "PATH");
				String name = String.format("role_%s", newRole.name().toLowerCase());
				try (InputStream is = CardImageReader.class.getResourceAsStream(String.format("%s/%s.png", PATH, name))) {
					assertNotNull(is, "Es wurde kein passendes Bild gefunden.");
				} catch (IOException e) {
					fail("Es wurde kein passendes Bild gefunden.");
				}
			}
			
		}
		
	}
	
}
